# Aivy - AI Nutrition & Fitness Companion

## Overview
Aivy is a stunning, mobile-first AI-powered nutrition and fitness companion built with React, Express, and OpenAI's GPT-5. The app combines cutting-edge AI technology with a beautiful, futuristic design to help users achieve their health goals through personalized coaching, food analysis, and nutrition tracking.

## Current State
**Status**: MVP Complete ✅

### Implemented Features
- ✅ **AI Food Scanner** - Upload food photos for instant AI-powered nutritional analysis using GPT-5 Vision
- ✅ **AI Coach Chat** - Conversational health advice and personalized recommendations from an AI assistant
- ✅ **Smart Nutrition Tracker** - Daily calorie and macro tracking with visual progress charts
- ✅ **Meal Planner** - AI-generated personalized 7-day meal plans based on user goals
- ✅ **User Profile** - Goal setting, dietary preferences, and progress tracking
- ✅ **Beautiful UI** - Mobile-optimized design with gradient effects, glassmorphic cards, and smooth animations
- ✅ **Dark Mode** - Full dark mode support with theme toggle
- ✅ **Real-time Stats** - Dashboard showing daily calories, macros, water intake, and streaks

## Recent Changes (December 2024)
- Implemented all data schemas and TypeScript interfaces for type-safe development
- Created complete OpenAI integration with GPT-5 Vision for food analysis and chat
- Built stunning frontend with 5 main pages: Home, Scan, Chat, Meal Planner, Profile
- Integrated all components with backend APIs using React Query
- Added beautiful loading states, error handling, and empty states
- Configured custom design tokens (blue-green gradients, neon accents) in Tailwind
- Generated AI coach avatar for brand identity

## Project Architecture

### Tech Stack
- **Frontend**: React 18, TypeScript, Tailwind CSS, Shadcn UI, Wouter (routing)
- **Backend**: Express, Node.js, OpenAI GPT-5
- **Data Visualization**: Recharts for charts and graphs
- **State Management**: TanStack Query (React Query)
- **Storage**: In-memory storage (MemStorage) for MVP
- **AI**: OpenAI GPT-5 for chat and GPT-5 Vision for image analysis

### Key Components
- **BottomNav**: Fixed bottom navigation with 5 tabs (Home, Scan, Coach, Meals, Profile)
- **StatCard**: Reusable glassmorphic stat cards with gradient icons
- **MacroChart**: Donut chart for macro breakdown visualization
- **ThemeToggle**: Dark/light mode switcher
- **LoadingState**: Beautiful loading indicators with pulse animations

### API Endpoints
- `POST /api/analyze-food` - Analyze food image with GPT-5 Vision
- `POST /api/chat` - Send message to AI coach
- `GET /api/chat-history` - Get conversation history
- `POST /api/meal-log` - Add meal to daily log
- `GET /api/meal-log` - Get meal logs (optionally filtered by date)
- `GET /api/daily-stats` - Get nutrition stats for a specific date
- `POST /api/generate-meal-plan` - Generate AI-powered 7-day meal plan
- `POST /api/generate-workout` - Generate personalized workout plan
- `GET /api/profile` - Get user profile
- `PUT /api/profile` - Update user profile

### Data Models
- **UserProfile**: User info, goals, activity level, macro targets
- **FoodAnalysis**: AI-analyzed food images with nutrition data
- **MealLog**: Daily meal entries with calories and macros
- **ChatMessage**: Conversation history with AI coach
- **MealPlan**: AI-generated weekly meal plans
- **WorkoutPlan**: Personalized workout routines
- **DailyStats**: Aggregated daily nutrition statistics

## User Preferences
- **Design Style**: Clean, futuristic, health-focused with soft gradients
- **Color Scheme**: Blue-green primary colors with neon cyan/purple accents
- **Typography**: Inter for body text, Outfit for headings
- **Target Audience**: Health-conscious users seeking AI-powered guidance
- **Platform**: Mobile-first responsive web application

## Design Guidelines
See `design_guidelines.md` for complete visual design specifications including:
- Color palette (light & dark modes)
- Typography scale
- Component styling (cards, buttons, inputs)
- Animation guidelines
- Accessibility standards

## Environment Variables
- `OPENAI_API_KEY` - Required for AI features (food analysis, chat, meal/workout generation)
- `SESSION_SECRET` - Session management (auto-configured)

## Development Commands
- `npm run dev` - Start development server (frontend + backend)
- Frontend runs on http://localhost:5000
- Hot reload enabled for both frontend and backend

## Next Phase Features (Post-MVP)
- [ ] Persistent database with PostgreSQL (replace in-memory storage)
- [ ] User authentication and multi-user support
- [ ] Push notifications for meal reminders and workout schedules
- [ ] Barcode scanning for packaged foods
- [ ] Detailed workout tracking with progress photos
- [ ] Social features (share progress, meal plans)
- [ ] Integration with fitness wearables (Apple Health, Google Fit)
- [ ] Advanced analytics and progress reports
- [ ] Recipe database with cooking instructions
- [ ] Water intake tracking with reminders

## Notes
- Using GPT-5 (released August 7, 2025) - the latest OpenAI model
- Mobile-optimized design with touch-friendly 44px minimum tap targets
- Glassmorphic design with backdrop-blur effects
- All interactive elements have proper hover/active states
- Gradient backgrounds use CSS custom properties for easy theming
- Bottom navigation fixed with safe-area padding for modern phones
