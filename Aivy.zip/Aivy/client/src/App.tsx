import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { BottomNav } from "@/components/BottomNav";
import { useAuth } from "@/hooks/useAuth";
import { LoadingState } from "@/components/LoadingState";
import Home from "@/pages/Home";
import Scan from "@/pages/Scan";
import Chat from "@/pages/Chat";
import MealPlanner from "@/pages/MealPlanner";
import Profile from "@/pages/Profile";
import SignIn from "@/pages/SignIn";
import SignUp from "@/pages/SignUp";
import VerifyEmail from "@/pages/VerifyEmail";
import Onboarding from "@/pages/Onboarding";

function ProtectedRoute({ component: Component }: { component: () => JSX.Element }) {
  const { user, loading } = useAuth();

  if (loading) {
    return <LoadingState text="Loading your profile..." />;
  }

  if (!user) {
    window.location.href = '/signin';
    return null;
  }

  return <Component />;
}

function PublicRoute({ component: Component }: { component: () => JSX.Element }) {
  const { user, loading } = useAuth();

  if (loading) {
    return <LoadingState text="Loading..." />;
  }

  if (user) {
    window.location.href = '/';
    return null;
  }

  return <Component />;
}

function Router() {
  return (
    <Switch>
      <Route path="/signin" component={() => <PublicRoute component={SignIn} />} />
      <Route path="/signup" component={() => <PublicRoute component={SignUp} />} />
      <Route path="/verify-email" component={VerifyEmail} />
      <Route path="/onboarding" component={Onboarding} />
      <Route path="/" component={() => <ProtectedRoute component={Home} />} />
      <Route path="/scan" component={() => <ProtectedRoute component={Scan} />} />
      <Route path="/chat" component={() => <ProtectedRoute component={Chat} />} />
      <Route path="/meals" component={() => <ProtectedRoute component={MealPlanner} />} />
      <Route path="/profile" component={() => <ProtectedRoute component={Profile} />} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="relative min-h-screen bg-background">
          <Router />
          <BottomNav />
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
