import { supabase } from './supabase';
import type { User } from '@supabase/supabase-js';

export async function signUpWithEmailOTP(email: string) {
  const { data, error } = await supabase.auth.signInWithOtp({
    email,
    options: {
      shouldCreateUser: true,
    },
  });

  if (error) throw error;
  return data;
}

export async function createUserProfile(userData: {
  user_id: string;
  name: string;
  email: string;
  age: number;
  height_cm: number;
  current_weight_kg: number;
  goal_weight_kg: number;
  goal: string;
  activity_level: string;
  dietary_restrictions: string[];
}) {
  const macros = calculateMacros(
    userData.goal,
    userData.current_weight_kg,
    userData.goal_weight_kg,
    userData.activity_level
  );

  const { data, error } = await supabase
    .from('user_profiles')
    .insert({
      ...userData,
      ...macros,
    })
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function signInWithGoogle() {
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: {
      redirectTo: `${window.location.origin}/onboarding`,
    },
  });

  if (error) throw error;
  return data;
}

export async function signIn(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) throw error;
  return data;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function getCurrentUser(): Promise<User | null> {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
}

export async function getUserProfile(userId: string) {
  const { data, error } = await supabase
    .from('user_profiles')
    .select('*')
    .eq('user_id', userId)
    .single();

  if (error) throw error;
  return data;
}

function calculateMacros(
  goal: string,
  currentWeight: number,
  goalWeight: number,
  activityLevel: string
) {
  let bmr = 0;
  const weight = currentWeight;

  const activityMultipliers: Record<string, number> = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    active: 1.725,
    'very-active': 1.9,
  };

  bmr = weight * 22;
  const tdee = bmr * (activityMultipliers[activityLevel] || 1.55);

  let dailyCalorieTarget = tdee;
  if (goal === 'lose-weight') {
    dailyCalorieTarget = tdee - 500;
  } else if (goal === 'gain-muscle') {
    dailyCalorieTarget = tdee + 300;
  }

  const proteinTarget = Math.round(weight * 2.2);
  const fatTarget = Math.round((dailyCalorieTarget * 0.25) / 9);
  const carbsTarget = Math.round((dailyCalorieTarget - (proteinTarget * 4 + fatTarget * 9)) / 4);

  return {
    daily_calorie_target: Math.round(dailyCalorieTarget),
    protein_target_g: proteinTarget,
    carbs_target_g: carbsTarget,
    fat_target_g: fatTarget,
  };
}
