import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('Supabase credentials not found. Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY environment variables.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Database = {
  public: {
    Tables: {
      user_profiles: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          email: string;
          age: number | null;
          height_cm: number | null;
          current_weight_kg: number | null;
          goal_weight_kg: number | null;
          goal: string;
          activity_level: string;
          daily_calorie_target: number;
          protein_target_g: number;
          carbs_target_g: number;
          fat_target_g: number;
          dietary_restrictions: string[];
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['user_profiles']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['user_profiles']['Insert']>;
      };
      meal_logs: {
        Row: {
          id: string;
          user_id: string;
          date: string;
          meal_name: string;
          meal_type: string;
          calories: number;
          protein_g: number;
          carbs_g: number;
          fat_g: number;
          image_url: string | null;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['meal_logs']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['meal_logs']['Insert']>;
      };
      chat_messages: {
        Row: {
          id: string;
          user_id: string;
          role: string;
          content: string;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['chat_messages']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['chat_messages']['Insert']>;
      };
      meal_plans: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          start_date: string;
          end_date: string;
          daily_meals: any;
          generated_by: string;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['meal_plans']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['meal_plans']['Insert']>;
      };
    };
  };
};
