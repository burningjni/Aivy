import { useState } from "react";
import { Sparkles, ChevronRight, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useMealPlans, useGenerateMealPlan } from "@/hooks/useApi";
import { LoadingState } from "@/components/LoadingState";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export default function MealPlanner() {
  const [selectedDay, setSelectedDay] = useState("monday");
  const { data: mealPlans = [], isLoading } = useMealPlans();
  const generatePlan = useGenerateMealPlan();
  const { toast } = useToast();

  const weekDays = [
    { id: "monday", label: "Mon", date: "Dec 18" },
    { id: "tuesday", label: "Tue", date: "Dec 19" },
    { id: "wednesday", label: "Wed", date: "Dec 20" },
    { id: "thursday", label: "Thu", date: "Dec 21" },
    { id: "friday", label: "Fri", date: "Dec 22" },
    { id: "saturday", label: "Sat", date: "Dec 23" },
    { id: "sunday", label: "Sun", date: "Dec 24" },
  ];

  // Get the most recent meal plan
  const currentPlan = mealPlans[0];
  const dayMeals = currentPlan?.dailyMeals?.[selectedDay];

  const handleGeneratePlan = async () => {
    try {
      await generatePlan.mutateAsync({});
      toast({
        title: "Meal Plan Generated!",
        description: "Your personalized 7-day meal plan is ready.",
      });
    } catch (error) {
      toast({
        title: "Generation Failed",
        description: "Could not generate meal plan. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background pb-24 px-4 pt-20">
        <LoadingState text="Loading your meal plans..." />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="bg-gradient-success px-6 pt-12 pb-6">
        <h1 className="text-3xl font-bold text-white font-display" data-testid="text-meal-planner-title">
          Meal Planner
        </h1>
        <p className="text-white/80 mt-1">AI-generated personalized plans</p>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* Generate New Plan CTA */}
        <Card className="p-6 bg-gradient-ai text-white shadow-glow-purple hover-elevate">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
              <Sparkles className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-lg mb-1">Create New Plan</h3>
              <p className="text-white/80 text-sm">
                Let AI generate a personalized meal plan based on your goals
              </p>
            </div>
            <Button 
              variant="secondary"
              className="rounded-full"
              onClick={handleGeneratePlan}
              disabled={generatePlan.isPending}
              data-testid="button-generate-plan"
            >
              <Plus className="w-4 h-4 mr-2" />
              {generatePlan.isPending ? "Generating..." : "Generate"}
            </Button>
          </div>
        </Card>

        {!currentPlan ? (
          <Card className="p-12 text-center">
            <Sparkles className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No Meal Plan Yet</h3>
            <p className="text-muted-foreground mb-6">
              Generate your first AI-powered meal plan tailored to your goals
            </p>
            <Button 
              className="bg-gradient-primary text-white shadow-glow-cyan"
              onClick={handleGeneratePlan}
              disabled={generatePlan.isPending}
            >
              <Sparkles className="w-4 h-4 mr-2" />
              {generatePlan.isPending ? "Generating..." : "Generate Meal Plan"}
            </Button>
          </Card>
        ) : (
          <>
            {/* Week Navigation */}
            <div className="overflow-x-auto pb-2 scrollbar-hide">
              <div className="flex gap-2 min-w-max">
                {weekDays.map((day) => (
                  <button
                    key={day.id}
                    onClick={() => setSelectedDay(day.id)}
                    className={cn(
                      "flex flex-col items-center p-4 rounded-2xl min-w-[80px] transition-all",
                      "hover-elevate active-elevate-2",
                      selectedDay === day.id
                        ? "bg-gradient-primary text-white shadow-glow-cyan"
                        : "bg-card border border-card-border"
                    )}
                    data-testid={`button-day-${day.id}`}
                  >
                    <span className="text-xs font-medium mb-1">{day.label}</span>
                    <span className="text-lg font-bold">{day.date.split(' ')[1]}</span>
                    <span className="text-xs opacity-80">{day.date.split(' ')[0]}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Meals for Selected Day */}
            {dayMeals ? (
              <div className="space-y-4">
                <h2 className="text-xl font-semibold font-display">
                  Meals for {weekDays.find(d => d.id === selectedDay)?.label}
                </h2>

                {["breakfast", "lunch", "dinner"].map((mealType) => {
                  const meal = dayMeals[mealType as keyof typeof dayMeals];
                  if (!meal || typeof meal === 'object' && 'length' in meal) return null;
                  
                  return (
                    <Card 
                      key={mealType} 
                      className="p-5 hover-elevate cursor-pointer"
                      data-testid={`card-meal-${mealType}`}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                              {mealType}
                            </span>
                            <span className="px-2 py-0.5 bg-primary/10 text-primary rounded-full text-xs font-medium">
                              {meal.calories} cal
                            </span>
                          </div>
                          <h3 className="font-semibold text-lg mb-1">{meal.name}</h3>
                          <p className="text-sm text-muted-foreground">{meal.description}</p>
                        </div>
                        <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-1" />
                      </div>
                      
                      <div className="flex gap-4 pt-3 border-t border-border">
                        <div className="text-center flex-1">
                          <p className="text-xs text-muted-foreground mb-1">Protein</p>
                          <p className="font-semibold font-mono text-sm">{meal.macros.protein}g</p>
                        </div>
                        <div className="text-center flex-1">
                          <p className="text-xs text-muted-foreground mb-1">Carbs</p>
                          <p className="font-semibold font-mono text-sm">{meal.macros.carbs}g</p>
                        </div>
                        <div className="text-center flex-1">
                          <p className="text-xs text-muted-foreground mb-1">Fats</p>
                          <p className="font-semibold font-mono text-sm">{meal.macros.fats}g</p>
                        </div>
                      </div>
                    </Card>
                  );
                })}

                {/* Daily Summary */}
                <Card className="p-6 bg-muted/30">
                  <h3 className="font-semibold mb-4">Daily Summary</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Total Calories</p>
                      <p className="text-2xl font-bold font-mono">
                        {dayMeals.breakfast.calories + dayMeals.lunch.calories + dayMeals.dinner.calories}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Macros</p>
                      <p className="text-sm font-mono">
                        P: {dayMeals.breakfast.macros.protein + dayMeals.lunch.macros.protein + dayMeals.dinner.macros.protein}g / 
                        C: {dayMeals.breakfast.macros.carbs + dayMeals.lunch.macros.carbs + dayMeals.dinner.macros.carbs}g / 
                        F: {dayMeals.breakfast.macros.fats + dayMeals.lunch.macros.fats + dayMeals.dinner.macros.fats}g
                      </p>
                    </div>
                  </div>
                </Card>
              </div>
            ) : (
              <Card className="p-12 text-center">
                <p className="text-muted-foreground">
                  No meals planned for this day
                </p>
              </Card>
            )}
          </>
        )}
      </div>
    </div>
  );
}
