import { User, Target, Activity, TrendingDown, Settings, Bell, Cloud } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { ThemeToggle } from "@/components/ThemeToggle";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useProfile } from "@/hooks/useApi";
import { LoadingState } from "@/components/LoadingState";

export default function Profile() {
  const { data: profile, isLoading } = useProfile();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background pb-24 px-4 pt-20">
        <LoadingState text="Loading your profile..." />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-background pb-24 px-4 pt-20">
        <p className="text-center text-muted-foreground">Profile not found</p>
      </div>
    );
  }

  const weightProgress = profile.currentWeight && profile.targetWeight 
    ? ((80 - profile.currentWeight) / (80 - profile.targetWeight)) * 100
    : 0;

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="bg-gradient-primary px-6 pt-12 pb-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold text-white font-display" data-testid="text-profile-title">
            Profile
          </h1>
          <ThemeToggle />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* User Info Card */}
        <Card className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <Avatar className="w-20 h-20">
              <AvatarImage src="" alt="User" />
              <AvatarFallback className="bg-gradient-primary text-white text-2xl font-bold">
                {profile.name.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h2 className="text-2xl font-bold" data-testid="text-user-name">{profile.name}</h2>
              <p className="text-muted-foreground">Member since Dec 2024</p>
            </div>
            <Button variant="outline" size="sm" data-testid="button-edit-profile">
              Edit
            </Button>
          </div>

          {/* Weight Progress */}
          {profile.currentWeight && profile.targetWeight && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Weight Progress</span>
                <span className="font-semibold">{profile.currentWeight}kg → {profile.targetWeight}kg</span>
              </div>
              <Progress value={weightProgress} className="h-2" />
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>Start: 80kg</span>
                <span>Goal: {profile.targetWeight}kg</span>
              </div>
            </div>
          )}
        </Card>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-4">
          <Card className="p-4 text-center" data-testid="card-stat-scans">
            <div className="inline-flex p-2 rounded-xl bg-primary/10 mb-2">
              <Activity className="w-5 h-5 text-primary" />
            </div>
            <p className="text-2xl font-bold font-mono">47</p>
            <p className="text-xs text-muted-foreground">Total Scans</p>
          </Card>
          <Card className="p-4 text-center" data-testid="card-stat-streak">
            <div className="inline-flex p-2 rounded-xl bg-health/10 mb-2">
              <TrendingDown className="w-5 h-5 text-health" />
            </div>
            <p className="text-2xl font-bold font-mono">12</p>
            <p className="text-xs text-muted-foreground">Day Streak</p>
          </Card>
          <Card className="p-4 text-center" data-testid="card-stat-meals">
            <div className="inline-flex p-2 rounded-xl bg-warning/10 mb-2">
              <Target className="w-5 h-5 text-warning" />
            </div>
            <p className="text-2xl font-bold font-mono">156</p>
            <p className="text-xs text-muted-foreground">Meals Logged</p>
          </Card>
        </div>

        {/* Goals Section */}
        <section>
          <h2 className="text-xl font-semibold font-display mb-4" data-testid="text-goals-section">
            Your Goals
          </h2>
          <Card className="p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold mb-1">Primary Goal</p>
                <p className="text-sm text-muted-foreground capitalize">
                  {profile.goal.replace('_', ' ')}
                </p>
              </div>
              <Button variant="outline" size="sm" data-testid="button-change-goal">
                Change
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Activity Level</p>
                <p className="font-semibold capitalize">{profile.activityLevel.replace('_', ' ')}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Daily Target</p>
                <p className="font-semibold">{profile.dailyCalorieTarget.toLocaleString()} cal</p>
              </div>
            </div>
          </Card>
        </section>

        {/* Dietary Preferences */}
        <section>
          <h2 className="text-xl font-semibold font-display mb-4">
            Dietary Preferences
          </h2>
          <Card className="p-5">
            <div className="space-y-3">
              <div className="flex items-center gap-2 flex-wrap">
                {profile.dietaryRestrictions.length > 0 ? (
                  profile.dietaryRestrictions.map((restriction) => (
                    <span 
                      key={restriction}
                      className="px-3 py-1 bg-health/10 text-health rounded-full text-sm font-medium capitalize"
                    >
                      {restriction}
                    </span>
                  ))
                ) : (
                  <span className="text-sm text-muted-foreground">No restrictions</span>
                )}
              </div>
              <Button variant="outline" size="sm" className="w-full" data-testid="button-update-preferences">
                Update Preferences
              </Button>
            </div>
          </Card>
        </section>

        {/* Settings */}
        <section>
          <h2 className="text-xl font-semibold font-display mb-4">Settings</h2>
          <Card className="divide-y divide-border">
            <div className="p-4 flex items-center justify-between" data-testid="setting-notifications">
              <div className="flex items-center gap-3">
                <Bell className="w-5 h-5 text-muted-foreground" />
                <div>
                  <p className="font-semibold">Notifications</p>
                  <p className="text-sm text-muted-foreground">Meal and workout reminders</p>
                </div>
              </div>
              <Switch defaultChecked />
            </div>
            <div className="p-4 flex items-center justify-between" data-testid="setting-sync">
              <div className="flex items-center gap-3">
                <Cloud className="w-5 h-5 text-muted-foreground" />
                <div>
                  <p className="font-semibold">Cloud Sync</p>
                  <p className="text-sm text-muted-foreground">Auto-sync across devices</p>
                </div>
              </div>
              <Switch defaultChecked />
            </div>
            <div className="p-4 flex items-center justify-between" data-testid="setting-preferences">
              <div className="flex items-center gap-3">
                <Settings className="w-5 h-5 text-muted-foreground" />
                <div>
                  <p className="font-semibold">Preferences</p>
                  <p className="text-sm text-muted-foreground">Manage app settings</p>
                </div>
              </div>
              <Button variant="ghost" size="sm">
                Manage
              </Button>
            </div>
          </Card>
        </section>

        {/* Premium Upgrade */}
        <Card className="p-6 bg-gradient-ai text-white shadow-glow-purple">
          <h3 className="text-xl font-bold mb-2">Upgrade to Premium</h3>
          <p className="text-white/80 text-sm mb-4">
            Unlock advanced AI features, personalized coaching, and detailed analytics
          </p>
          <Button 
            variant="secondary" 
            className="w-full"
            data-testid="button-upgrade-premium"
          >
            Learn More
          </Button>
        </Card>
      </div>
    </div>
  );
}
