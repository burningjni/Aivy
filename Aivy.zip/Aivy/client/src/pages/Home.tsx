import { Flame, Apple, Droplet, TrendingUp, Sparkles } from "lucide-react";
import { StatCard } from "@/components/StatCard";
import { MacroChart } from "@/components/MacroChart";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import aiAvatarImage from "@assets/generated_images/AI_coach_avatar_icon_95984255.png";
import { useProfile, useDailyStats, useWeeklyStats, useStreak } from "@/hooks/useApi";
import { LoadingState, SkeletonCard } from "@/components/LoadingState";

export default function Home() {
  const { data: profile, isLoading: profileLoading } = useProfile();
  const { data: stats, isLoading: statsLoading } = useDailyStats();
  const { data: weeklyData, isLoading: weeklyLoading } = useWeeklyStats();
  const { data: streakData, isLoading: streakLoading } = useStreak();

  // Transform weekly data for chart display
  const weeklyCalories = weeklyData?.map((day, index) => {
    const date = new Date(day.date);
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    return {
      day: dayNames[date.getDay()],
      calories: day.calories,
    };
  }) || [];

  const caloriesRemaining = profile ? profile.dailyCalorieTarget - (stats?.totalCalories || 0) : 0;
  const mealsToday = stats?.mealsLogged || 0;
  const waterTarget = 2000; // 2L target
  const waterRemaining = waterTarget - (stats?.waterIntakeMl || 0);

  if (profileLoading || statsLoading) {
    return (
      <div className="min-h-screen bg-background pb-24 px-4 pt-20">
        <LoadingState text="Loading your health dashboard..." />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Hero Section */}
      <div className="bg-gradient-primary px-6 pt-12 pb-8 mb-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-4xl font-bold text-white font-display" data-testid="text-welcome">
                Hello, {profile?.name.split(' ')[0] || 'there'}
              </h1>
              <p className="text-primary-foreground/80 mt-1">Ready to crush your goals?</p>
            </div>
            <img 
              src={aiAvatarImage} 
              alt="Aivy AI Coach" 
              className="w-16 h-16 rounded-full shadow-glow-purple"
              data-testid="img-ai-avatar"
            />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 space-y-6">
        {/* Today's Summary */}
        <section>
          <h2 className="text-2xl font-semibold font-display mb-4" data-testid="text-today-summary">
            Today's Summary
          </h2>
          <div className="grid grid-cols-2 gap-4">
            <StatCard
              title="Calories"
              value={stats?.totalCalories.toLocaleString() || "0"}
              subtitle={`${caloriesRemaining} remaining`}
              icon={Flame}
              trend={stats?.totalCalories && stats.totalCalories < (profile?.dailyCalorieTarget || 2000) ? "up" : "neutral"}
              gradient="primary"
            />
            <StatCard
              title="Meals"
              value={`${mealsToday}/3`}
              subtitle={mealsToday < 3 ? `${3 - mealsToday} to go` : "Complete!"}
              icon={Apple}
              trend={mealsToday >= 3 ? "up" : "neutral"}
              gradient="success"
            />
            <StatCard
              title="Water"
              value={`${((stats?.waterIntakeMl || 0) / 1000).toFixed(1)}L`}
              subtitle={waterRemaining > 0 ? `${(waterRemaining / 1000).toFixed(1)}L to go` : "Goal reached!"}
              icon={Droplet}
              trend={(stats?.waterIntakeMl || 0) >= waterTarget ? "up" : "neutral"}
              gradient="primary"
            />
            <StatCard
              title="Streak"
              value={streakData?.streak || 0}
              subtitle="days"
              icon={TrendingUp}
              trend={(streakData?.streak || 0) > 0 ? "up" : "neutral"}
              gradient="success"
            />
          </div>
        </section>

        {/* AI Insight Card */}
        <Card className="p-6 bg-gradient-ai text-white shadow-glow-purple" data-testid="card-ai-insight">
          <div className="flex items-start gap-4">
            <div className="p-2 bg-white/20 rounded-xl backdrop-blur-sm">
              <Sparkles className="w-6 h-6 animate-pulse-glow" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-lg mb-2">AI Insight</h3>
              <p className="text-white/90 text-sm leading-relaxed">
                {stats?.totalCalories && stats.totalCalories > 0
                  ? `You've consumed ${stats.totalCalories} calories today. ${
                      caloriesRemaining > 0
                        ? `You have ${caloriesRemaining} calories remaining for the day.`
                        : "You've reached your daily goal!"
                    }`
                  : "Start logging your meals to get personalized insights from your AI coach!"}
              </p>
            </div>
          </div>
        </Card>

        {/* Macro Breakdown */}
        <section>
          <h2 className="text-2xl font-semibold font-display mb-4" data-testid="text-macros">
            Today's Macros
          </h2>
          <Card className="p-6">
            <MacroChart 
              protein={stats?.macros.protein || 0}
              carbs={stats?.macros.carbs || 0}
              fats={stats?.macros.fats || 0}
            />
            <div className="grid grid-cols-3 gap-4 mt-6">
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Protein</p>
                <p className="text-xl font-bold font-mono">{stats?.macros.protein || 0}g</p>
                <p className="text-xs text-health">
                  {profile && Math.round((stats?.macros.protein || 0) / profile.macroTargets.protein * 100)}% of goal
                </p>
              </div>
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Carbs</p>
                <p className="text-xl font-bold font-mono">{stats?.macros.carbs || 0}g</p>
                <p className="text-xs text-health">
                  {profile && Math.round((stats?.macros.carbs || 0) / profile.macroTargets.carbs * 100)}% of goal
                </p>
              </div>
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Fats</p>
                <p className="text-xl font-bold font-mono">{stats?.macros.fats || 0}g</p>
                <p className="text-xs text-health">
                  {profile && Math.round((stats?.macros.fats || 0) / profile.macroTargets.fats * 100)}% of goal
                </p>
              </div>
            </div>
          </Card>
        </section>

        {/* Weekly Progress */}
        <section>
          <h2 className="text-2xl font-semibold font-display mb-4" data-testid="text-weekly-progress">
            Weekly Calorie Trend
          </h2>
          <Card className="p-6">
            <div className="h-48 w-full" data-testid="chart-weekly-calories">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={weeklyCalories}>
                  <XAxis 
                    dataKey="day" 
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="calories" 
                    stroke="hsl(var(--primary))"
                    strokeWidth={3}
                    dot={{ fill: "hsl(var(--primary))", r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </section>

        {/* Quick Actions */}
        <section>
          <h2 className="text-2xl font-semibold font-display mb-4">Quick Actions</h2>
          <div className="grid grid-cols-2 gap-4">
            <Link href="/scan">
              <Button 
                className="w-full h-auto py-6 flex flex-col gap-2 bg-gradient-primary text-white shadow-glow-cyan"
                data-testid="button-scan-food"
              >
                <Flame className="w-8 h-8" />
                <span className="font-semibold">Scan Food</span>
              </Button>
            </Link>
            <Link href="/chat">
              <Button 
                className="w-full h-auto py-6 flex flex-col gap-2 bg-gradient-ai text-white shadow-glow-purple"
                data-testid="button-ask-aivy"
              >
                <Sparkles className="w-8 h-8" />
                <span className="font-semibold">Ask Aivy</span>
              </Button>
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
