import { useState, useRef } from "react";
import { Camera, Upload, X, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MacroChart } from "@/components/MacroChart";
import { useAnalyzeFood, useAddMealLog } from "@/hooks/useApi";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import type { FoodAnalysis } from "@shared/schema";

export default function Scan() {
  const [image, setImage] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [result, setResult] = useState<FoodAnalysis | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const analyzeFood = useAnalyzeFood();
  const addMealLog = useAddMealLog();
  const { toast } = useToast();

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);

      // Analyze the image
      try {
        const analysis = await analyzeFood.mutateAsync(file);
        setResult(analysis);
        toast({
          title: "Analysis Complete!",
          description: `Identified: ${analysis.foodName}`,
        });
      } catch (error) {
        toast({
          title: "Analysis Failed",
          description: "Could not analyze the image. Please try again.",
          variant: "destructive",
        });
      }
    }
  };

  const handleReset = () => {
    setImage(null);
    setSelectedFile(null);
    setResult(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleAddToLog = async () => {
    if (!result) return;

    try {
      await addMealLog.mutateAsync({
        date: new Date().toISOString().split('T')[0],
        mealType: "snack",
        foodName: result.foodName,
        calories: result.calories,
        macros: result.macros,
        imageUrl: result.imageUrl,
      });

      toast({
        title: "Added to Log!",
        description: `${result.foodName} has been logged.`,
      });

      handleReset();
    } catch (error) {
      toast({
        title: "Failed to Log",
        description: "Could not add meal to log. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="bg-gradient-primary px-6 pt-12 pb-6">
        <h1 className="text-3xl font-bold text-white font-display" data-testid="text-scan-title">
          AI Food Scanner
        </h1>
        <p className="text-primary-foreground/80 mt-1">
          Upload a photo to analyze nutrition
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {!image ? (
          <div className="space-y-4">
            <Card className="p-8 border-2 border-dashed border-primary/30 bg-card/50">
              <div className="text-center space-y-4">
                <div className="inline-flex p-6 rounded-full bg-gradient-primary shadow-glow-cyan">
                  <Camera className="w-12 h-12 text-white" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold mb-2">Upload Food Photo</h2>
                  <p className="text-muted-foreground text-sm">
                    Take a photo or upload from your gallery
                  </p>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  data-testid="input-file-upload"
                />
                <div className="flex flex-col gap-3 pt-4">
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full bg-gradient-primary text-white shadow-glow-cyan"
                    size="lg"
                    data-testid="button-upload-photo"
                  >
                    <Upload className="w-5 h-5 mr-2" />
                    Choose Photo
                  </Button>
                </div>
              </div>
            </Card>

            <Card className="p-6 bg-muted/30">
              <h3 className="font-semibold mb-3">Tips for best results:</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-health mt-0.5 flex-shrink-0" />
                  <span>Take photo from above at a slight angle</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-health mt-0.5 flex-shrink-0" />
                  <span>Ensure good lighting and clear visibility</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-health mt-0.5 flex-shrink-0" />
                  <span>Include the entire plate or portion</span>
                </li>
              </ul>
            </Card>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Image Preview */}
            <Card className="overflow-hidden">
              <div className="relative">
                <img 
                  src={image} 
                  alt="Food to analyze" 
                  className="w-full h-64 object-cover"
                  data-testid="img-food-preview"
                />
                <Button
                  onClick={handleReset}
                  variant="destructive"
                  size="icon"
                  className="absolute top-4 right-4 rounded-full shadow-lg"
                  data-testid="button-reset"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>
            </Card>

            {analyzeFood.isPending ? (
              <Card className="p-12">
                <div className="flex flex-col items-center justify-center space-y-4" data-testid="loading-analysis">
                  <div className="relative w-20 h-20">
                    <div className="absolute inset-0 rounded-full bg-gradient-primary opacity-20 animate-ping" />
                    <div className="absolute inset-0 rounded-full bg-gradient-primary opacity-75 animate-pulse" />
                  </div>
                  <div className="text-center">
                    <p className="font-semibold mb-1">Analyzing with AI...</p>
                    <p className="text-sm text-muted-foreground">
                      Identifying food and calculating nutrition
                    </p>
                  </div>
                </div>
              </Card>
            ) : result ? (
              <div className="space-y-4">
                {/* Food Name & Confidence */}
                <Card className="p-6 bg-gradient-success text-white shadow-glow-green">
                  <div className="flex items-start justify-between mb-2">
                    <h2 className="text-2xl font-bold" data-testid="text-food-name">
                      {result.foodName}
                    </h2>
                    <span className="px-3 py-1 bg-white/20 rounded-full text-sm font-medium backdrop-blur-sm">
                      {Math.round(result.confidence * 100)}% confident
                    </span>
                  </div>
                  <p className="text-white/90">{result.servingSize}</p>
                </Card>

                {/* Calories */}
                <Card className="p-8 text-center">
                  <p className="text-sm text-muted-foreground mb-2">Total Calories</p>
                  <p className="text-5xl font-bold font-mono bg-gradient-primary bg-clip-text text-transparent" data-testid="text-calories">
                    {result.calories}
                  </p>
                  <p className="text-muted-foreground mt-2">kcal</p>
                </Card>

                {/* Macros Breakdown */}
                <Card className="p-6">
                  <h3 className="font-semibold text-lg mb-4">Macro Breakdown</h3>
                  <MacroChart 
                    protein={result.macros.protein}
                    carbs={result.macros.carbs}
                    fats={result.macros.fats}
                  />
                </Card>

                {/* Action Buttons */}
                <div className="grid grid-cols-2 gap-4">
                  <Button
                    variant="outline"
                    onClick={handleReset}
                    data-testid="button-scan-another"
                    disabled={addMealLog.isPending}
                  >
                    Scan Another
                  </Button>
                  <Button
                    className="bg-gradient-primary text-white shadow-glow-cyan"
                    onClick={handleAddToLog}
                    disabled={addMealLog.isPending}
                    data-testid="button-add-to-log"
                  >
                    <Check className="w-4 h-4 mr-2" />
                    {addMealLog.isPending ? "Adding..." : "Add to Log"}
                  </Button>
                </div>
              </div>
            ) : null}
          </div>
        )}
      </div>
    </div>
  );
}
