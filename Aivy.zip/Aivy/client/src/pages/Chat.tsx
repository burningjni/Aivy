import { useState, useRef, useEffect } from "react";
import { Send, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { useChatHistory, useSendMessage } from "@/hooks/useApi";
import { LoadingState } from "@/components/LoadingState";
import { cn } from "@/lib/utils";
import aiAvatarImage from "@assets/generated_images/AI_coach_avatar_icon_95984255.png";

export default function Chat() {
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const { data: messages = [], isLoading } = useChatHistory();
  const sendMessage = useSendMessage();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || sendMessage.isPending) return;

    const userMessage = input;
    setInput("");

    try {
      await sendMessage.mutateAsync(userMessage);
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };

  const quickActions = [
    "What should I eat for breakfast?",
    "Create a workout plan",
    "Explain my macro targets",
    "Tips for better sleep",
  ];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background pb-24">
        <LoadingState text="Loading your conversation..." />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-ai px-6 pt-12 pb-6 flex-shrink-0">
        <div className="flex items-center gap-4">
          <img 
            src={aiAvatarImage} 
            alt="Aivy AI Coach" 
            className="w-14 h-14 rounded-full shadow-glow-purple animate-pulse-glow"
            data-testid="img-coach-avatar"
          />
          <div>
            <h1 className="text-2xl font-bold text-white font-display" data-testid="text-coach-title">
              Aivy Coach
            </h1>
            <p className="text-white/80 text-sm">Your AI Health Companion</p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-4 pb-32">
        {messages.length === 0 && (
          <Card className="p-6 bg-gradient-ai text-white shadow-glow-purple">
            <div className="flex items-start gap-3">
              <Sparkles className="w-6 h-6 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-semibold text-lg mb-2">Welcome to Aivy Coach!</h3>
                <p className="text-white/90 text-sm leading-relaxed">
                  I'm here to help you with nutrition advice, workout plans, and answer any health-related questions. 
                  Feel free to ask me anything about your fitness journey!
                </p>
              </div>
            </div>
          </Card>
        )}

        {messages.map((message, index) => (
          <div
            key={message.id}
            className={cn(
              "flex gap-3 animate-slide-in-left",
              message.role === "user" ? "flex-row-reverse" : "flex-row"
            )}
            data-testid={`message-${message.role}-${index}`}
          >
            {message.role === "assistant" && (
              <img 
                src={aiAvatarImage} 
                alt="Aivy" 
                className="w-8 h-8 rounded-full flex-shrink-0 mt-1"
              />
            )}
            <Card
              className={cn(
                "p-4 max-w-[80%]",
                message.role === "user" 
                  ? "bg-primary text-primary-foreground ml-auto" 
                  : "bg-gradient-ai text-white shadow-glow-purple"
              )}
            >
              <p className="text-sm leading-relaxed whitespace-pre-wrap">
                {message.content}
              </p>
              <p className={cn(
                "text-xs mt-2 opacity-70",
                message.role === "user" ? "text-right" : "text-left"
              )}>
                {new Date(message.timestamp).toLocaleTimeString([], { 
                  hour: '2-digit', 
                  minute: '2-digit' 
                })}
              </p>
            </Card>
          </div>
        ))}

        {sendMessage.isPending && (
          <div className="flex gap-3" data-testid="typing-indicator">
            <img 
              src={aiAvatarImage} 
              alt="Aivy" 
              className="w-8 h-8 rounded-full flex-shrink-0 mt-1"
            />
            <Card className="p-4 bg-gradient-ai text-white">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                <span className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                <span className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
              </div>
            </Card>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Actions */}
      {messages.length === 0 && (
        <div className="px-4 py-2 flex-shrink-0">
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {quickActions.map((action) => (
              <Button
                key={action}
                variant="outline"
                size="sm"
                onClick={() => setInput(action)}
                className="whitespace-nowrap flex-shrink-0 rounded-full"
                data-testid={`button-quick-${action.split(' ')[0].toLowerCase()}`}
              >
                {action}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Input Bar */}
      <div className="fixed bottom-20 left-0 right-0 bg-card/80 backdrop-blur-xl border-t border-card-border p-4">
        <div className="max-w-7xl mx-auto flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && !sendMessage.isPending && handleSend()}
            placeholder="Ask Aivy anything..."
            className="flex-1 rounded-full"
            disabled={sendMessage.isPending}
            data-testid="input-chat-message"
          />
          <Button
            onClick={handleSend}
            disabled={!input.trim() || sendMessage.isPending}
            className="rounded-full bg-gradient-primary text-white shadow-glow-cyan"
            size="icon"
            data-testid="button-send-message"
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
