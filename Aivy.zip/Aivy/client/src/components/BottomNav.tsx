import { Home, Camera, MessageCircle, UtensilsCrossed, User } from "lucide-react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

export function BottomNav() {
  const [location] = useLocation();

  const tabs = [
    { path: "/", icon: Home, label: "Home" },
    { path: "/scan", icon: Camera, label: "Scan" },
    { path: "/chat", icon: MessageCircle, label: "Coach" },
    { path: "/meals", icon: UtensilsCrossed, label: "Meals" },
    { path: "/profile", icon: User, label: "Profile" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-card/80 backdrop-blur-xl border-t border-card-border safe-bottom">
      <div className="max-w-7xl mx-auto px-2 py-2">
        <div className="flex justify-around items-center gap-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = location === tab.path;
            
            return (
              <Link key={tab.path} href={tab.path}>
                <div
                  data-testid={`nav-${tab.label.toLowerCase()}`}
                  className={cn(
                    "flex flex-col items-center justify-center px-4 py-2 rounded-xl transition-all duration-200 min-w-[64px] cursor-pointer",
                    "hover-elevate active-elevate-2",
                    isActive && "bg-gradient-primary text-primary-foreground shadow-glow-cyan"
                  )}
                >
                  <Icon className={cn("w-5 h-5 mb-1", isActive && "animate-pulse-glow")} />
                  <span className="text-xs font-medium">{tab.label}</span>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
