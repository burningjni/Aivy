import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from "recharts";

interface MacroChartProps {
  protein: number;
  carbs: number;
  fats: number;
}

export function MacroChart({ protein, carbs, fats }: MacroChartProps) {
  const data = [
    { name: "Protein", value: protein, color: "hsl(210 85% 55%)" },
    { name: "Carbs", value: carbs, color: "hsl(150 70% 50%)" },
    { name: "Fats", value: fats, color: "hsl(30 95% 60%)" },
  ];

  return (
    <div className="w-full h-64" data-testid="chart-macros">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={80}
            paddingAngle={5}
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <Legend 
            verticalAlign="bottom" 
            height={36}
            formatter={(value, entry: any) => (
              <span className="text-sm font-medium">
                {value}: {entry.payload.value}g
              </span>
            )}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
