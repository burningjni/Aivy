import { Card } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  trend?: "up" | "down" | "neutral";
  gradient?: "primary" | "success" | "warning";
  className?: string;
}

export function StatCard({ 
  title, 
  value, 
  subtitle, 
  icon: Icon, 
  trend,
  gradient = "primary",
  className 
}: StatCardProps) {
  const gradientClasses = {
    primary: "bg-gradient-primary",
    success: "bg-gradient-success",
    warning: "from-warning to-orange-400",
  };

  return (
    <Card className={cn("p-6 hover-elevate", className)} data-testid={`card-stat-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <p className="text-sm font-medium text-muted-foreground mb-1">{title}</p>
          <p className="text-3xl font-bold font-mono">{value}</p>
          {subtitle && (
            <p className="text-sm text-muted-foreground mt-2">{subtitle}</p>
          )}
        </div>
        <div className={cn(
          "p-3 rounded-2xl",
          gradientClasses[gradient],
          "shadow-lg"
        )}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
      {trend && (
        <div className={cn(
          "text-sm font-medium",
          trend === "up" && "text-health",
          trend === "down" && "text-destructive",
          trend === "neutral" && "text-muted-foreground"
        )}>
          {trend === "up" && "↗ Improving"}
          {trend === "down" && "↘ Attention needed"}
          {trend === "neutral" && "→ Stable"}
        </div>
      )}
    </Card>
  );
}
