import { cn } from "@/lib/utils";

interface LoadingStateProps {
  text?: string;
  className?: string;
}

export function LoadingState({ text = "Loading...", className }: LoadingStateProps) {
  return (
    <div className={cn("flex flex-col items-center justify-center py-12", className)} data-testid="loading-state">
      <div className="relative w-16 h-16 mb-4">
        <div className="absolute inset-0 rounded-full bg-gradient-primary opacity-20 animate-ping" />
        <div className="absolute inset-0 rounded-full bg-gradient-primary opacity-75 animate-pulse" />
      </div>
      <p className="text-sm text-muted-foreground">{text}</p>
    </div>
  );
}

export function SkeletonCard() {
  return (
    <div className="p-6 rounded-2xl border border-card-border bg-card animate-pulse" data-testid="skeleton-card">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1 space-y-2">
          <div className="h-4 bg-muted rounded w-24" />
          <div className="h-8 bg-muted rounded w-32" />
        </div>
        <div className="w-12 h-12 bg-muted rounded-2xl" />
      </div>
      <div className="h-4 bg-muted rounded w-20" />
    </div>
  );
}
