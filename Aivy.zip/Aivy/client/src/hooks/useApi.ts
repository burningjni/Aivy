import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { UserProfile, FoodAnalysis, MealLog, ChatMessage, DailyStats, MealPlan, WorkoutPlan } from "@shared/schema";

// Profile hooks
export function useProfile() {
  return useQuery<UserProfile>({
    queryKey: ["/api/profile"],
  });
}

export function useUpdateProfile() {
  return useMutation({
    mutationFn: async (data: Partial<UserProfile>) => {
      return apiRequest("PUT", "/api/profile", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      queryClient.invalidateQueries({ queryKey: ["/api/daily-stats"] });
    },
  });
}

// Food Analysis hooks
export function useAnalyzeFood() {
  return useMutation({
    mutationFn: async (imageFile: File) => {
      const formData = new FormData();
      formData.append("image", imageFile);
      
      const response = await fetch("/api/analyze-food", {
        method: "POST",
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error("Failed to analyze food");
      }
      
      return response.json();
    },
  });
}

// Meal Log hooks
export function useMealLogs(date?: string) {
  return useQuery<MealLog[]>({
    queryKey: ["/api/meal-log", date],
    queryFn: async () => {
      const url = date ? `/api/meal-log?date=${date}` : "/api/meal-log";
      const response = await fetch(url);
      if (!response.ok) throw new Error("Failed to fetch meal logs");
      return response.json();
    },
  });
}

export function useAddMealLog() {
  return useMutation({
    mutationFn: async (data: {
      date: string;
      mealType: "breakfast" | "lunch" | "dinner" | "snack";
      foodName: string;
      calories: number;
      macros: { protein: number; carbs: number; fats: number };
      imageUrl?: string;
    }) => {
      return apiRequest("POST", "/api/meal-log", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meal-log"] });
      queryClient.invalidateQueries({ queryKey: ["/api/daily-stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/weekly-stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/streak"] });
    },
  });
}

// Daily Stats hooks
export function useDailyStats(date?: string) {
  return useQuery<DailyStats>({
    queryKey: ["/api/daily-stats", date],
    queryFn: async () => {
      const url = date ? `/api/daily-stats?date=${date}` : "/api/daily-stats";
      const response = await fetch(url);
      if (!response.ok) throw new Error("Failed to fetch daily stats");
      return response.json();
    },
  });
}

// Weekly Stats hooks
export function useWeeklyStats() {
  return useQuery<Array<{ date: string; calories: number }>>({
    queryKey: ["/api/weekly-stats"],
  });
}

// User Streak hook
export function useStreak() {
  return useQuery<{ streak: number }>({
    queryKey: ["/api/streak"],
  });
}

// Water Log hooks
export function useAddWaterLog() {
  return useMutation({
    mutationFn: async (amountMl: number) => {
      return apiRequest("POST", "/api/water-log", { amountMl });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/daily-stats"] });
    },
  });
}

export function useWaterLogs(date?: string) {
  return useQuery({
    queryKey: ["/api/water-log", date],
    queryFn: async () => {
      const url = date ? `/api/water-log?date=${date}` : "/api/water-log";
      const response = await fetch(url);
      if (!response.ok) throw new Error("Failed to fetch water logs");
      return response.json();
    },
  });
}

// Chat hooks
export function useChatHistory() {
  return useQuery<ChatMessage[]>({
    queryKey: ["/api/chat-history"],
  });
}

export function useSendMessage() {
  return useMutation({
    mutationFn: async (message: string) => {
      return apiRequest("POST", "/api/chat", { message });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat-history"] });
    },
  });
}

// Meal Plan hooks
export function useMealPlans() {
  return useQuery<MealPlan[]>({
    queryKey: ["/api/meal-plans"],
  });
}

export function useGenerateMealPlan() {
  return useMutation({
    mutationFn: async (data?: { name?: string; startDate?: string; endDate?: string }) => {
      return apiRequest("POST", "/api/generate-meal-plan", data || {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meal-plans"] });
    },
  });
}

// Workout Plan hooks
export function useWorkoutPlans() {
  return useQuery<WorkoutPlan[]>({
    queryKey: ["/api/workout-plans"],
  });
}

export function useGenerateWorkout() {
  return useMutation({
    mutationFn: async (data?: { fitnessLevel?: string; focusAreas?: string[] }) => {
      return apiRequest("POST", "/api/generate-workout", data || {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workout-plans"] });
    },
  });
}
