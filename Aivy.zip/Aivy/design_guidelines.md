# Aivy Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from modern health apps (MyFitnessPal, Noom) combined with futuristic AI interfaces (OpenAI ChatGPT, Linear) to create a next-generation health companion that feels both trustworthy and cutting-edge.

**Core Design Principle**: Aivy should feel like a personal AI health companion - intelligent, supportive, and visually sophisticated. Every interaction should reinforce the sense of having an advanced AI working for the user's health goals.

---

## Color Palette

**Primary Colors (Light Mode)**:
- Primary Blue: 210 85% 55% (vibrant sky blue for primary actions)
- Health Green: 150 70% 50% (positive health indicators, success states)
- Background: 0 0% 98% (soft white for main surfaces)
- Surface: 0 0% 100% (pure white for cards and elevated elements)

**Primary Colors (Dark Mode)**:
- Primary Blue: 210 90% 60% (brighter for contrast)
- Health Green: 150 75% 55% (vibrant green)
- Background: 220 15% 10% (deep blue-tinted dark)
- Surface: 220 12% 15% (elevated card backgrounds)

**Accent Colors**:
- Neon Cyan: 180 100% 50% (glowing accents, AI indicators)
- Neon Purple: 270 100% 65% (premium features, AI chat bubbles)
- Warning Orange: 30 95% 60% (calorie alerts)
- Text Primary: 220 20% 15% / 0 0% 95% (light/dark)
- Text Secondary: 220 10% 45% / 0 0% 65% (light/dark)

**Gradient Combinations**:
- Hero Gradient: Blue to Cyan (210 85% 55% to 180 100% 50%)
- AI Glow: Purple to Blue (270 100% 65% to 210 90% 60%)
- Success: Green to Cyan (150 70% 50% to 180 100% 50%)

---

## Typography

**Font Stack**: 
- Primary: 'Inter' from Google Fonts (clean, modern, excellent readability)
- Accent/Headers: 'Outfit' from Google Fonts (futuristic, slightly rounded)

**Type Scale**:
- Hero/App Title: text-4xl font-bold (Outfit)
- Section Headers: text-2xl font-semibold (Outfit)
- Card Titles: text-lg font-semibold (Inter)
- Body Text: text-base font-normal (Inter)
- Captions/Labels: text-sm font-medium (Inter)
- Tiny/Metadata: text-xs (Inter)

**Special Typography**:
- AI responses: Slightly larger (text-lg) with gradient text effect
- Calorie numbers: Bold, large (text-3xl to text-5xl) with neon glow
- Stats/Metrics: Monospace for numbers (font-mono)

---

## Layout System

**Mobile-First Grid**: 
- Base spacing units: 1, 2, 4, 6, 8, 12, 16, 20 (Tailwind spacing)
- Common padding: p-4 to p-6 for mobile, p-6 to p-8 for tablet
- Card spacing: gap-4 to gap-6 between elements
- Section spacing: mb-8 to mb-12 between major sections

**Container Strategy**:
- Main content: px-4 on mobile, max-w-7xl centered on tablet+
- Cards: Rounded corners (rounded-2xl to rounded-3xl) with subtle shadows
- Floating action buttons: Fixed bottom positioning with safe-area padding

**Layout Patterns**:
- Dashboard: Grid-based cards (1 column mobile, 2 columns tablet)
- Food Scanner: Full-width camera viewport with overlay controls
- Chat: Full-height conversation interface with sticky input
- Stats: Horizontal scroll for metric cards on mobile

---

## Component Library

### Navigation
- **Bottom Tab Bar**: Fixed bottom navigation with 5 tabs (Home, Scan, Coach, Meals, Profile)
  - Glowing indicator for active tab with neon accent
  - Icons with labels, smooth transitions between tabs
  - Backdrop blur effect (backdrop-blur-xl) for modern feel

### Cards & Surfaces
- **Stat Cards**: Glassmorphic effect with subtle gradient borders
  - Background: bg-white/80 dark:bg-surface/80 with backdrop-blur
  - Border: 1px gradient border using neon colors
  - Shadow: Soft glow effect matching card purpose (green for nutrition, blue for fitness)
  
- **AI Response Cards**: Distinct styling for AI-generated content
  - Gradient background (purple to blue)
  - White text with high contrast
  - Subtle pulse animation on new messages

### Buttons
- **Primary CTA**: Gradient fill (blue to cyan), white text, rounded-full, shadow-lg with glow
- **Secondary**: Outline with gradient border, transparent background with blur
- **Icon Buttons**: Circular, soft background with hover lift effect
- **Scan Button**: Large circular FAB in center bottom with camera icon and pulsing ring animation

### Input Fields
- **Text Inputs**: Rounded-2xl, subtle border, focus state with neon glow
- **Chat Input**: Sticky bottom bar with blur background, rounded pill shape
- **Search**: Icon prefix, clear button suffix, gradient focus ring

### Data Visualization
- **Progress Rings**: Circular progress with gradient stroke (green for calories, blue for macros)
- **Bar Charts**: Rounded bars with gradient fills, subtle grid lines
- **Line Charts**: Smooth curves with gradient area fill, glowing data points
- **Macro Breakdown**: Donut chart with color-coded segments (protein, carbs, fats)

### Modals & Overlays
- **Food Analysis Result**: Full-screen modal with blur background
  - Hero food image at top
  - Nutrition breakdown in cards below
  - Swipe-down to dismiss gesture
  
- **AI Coach Chat**: Full-screen interface
  - Gradient header with AI avatar
  - Message bubbles: User (white/gray), AI (gradient purple-blue)
  - Typing indicator with animated dots

---

## Animations & Interactions

**Micro-interactions** (use sparingly):
- Scan button: Gentle pulse (1.5s interval) to draw attention
- New AI message: Slide-in from left with fade
- Success states: Scale bounce (scale-105) for 200ms
- Tab switches: Smooth fade between content (300ms)
- Pull-to-refresh: Elastic bounce with spinner

**Page Transitions**:
- Slide transitions between main sections (300ms ease-in-out)
- Fade for modal overlays (200ms)
- Scan result: Scale-up from camera button (400ms)

**Glow Effects**:
- Active elements: box-shadow with neon color at 50% opacity
- AI indicators: Subtle pulsing glow (2s interval)
- Stats achievement: Brief flash animation on goal completion

**Critical Rule**: Animations should feel instant and responsive. Never sacrifice performance for visual flair.

---

## Page-Specific Guidelines

### 1. Home Dashboard
- **Hero Section**: Welcome message with user's name and AI avatar
- **Today's Summary**: Large stat cards showing calories consumed/remaining, macros, water intake
- **AI Insight Card**: Daily tip or recommendation with gradient background
- **Quick Actions**: Scan food, log meal, start workout (icon buttons)
- **Progress Chart**: Weekly calorie trend with line graph
- **Upcoming**: Next meal reminder or workout suggestion

### 2. Scan Page
- **Camera View**: Full-screen camera feed with overlay UI
- **Capture Button**: Large circular button with pulsing ring
- **Gallery Access**: Small icon to upload from photos
- **Analysis Overlay**: Blur background with food item cards showing nutrition
- **Save Options**: Add to today's log, save to favorites

### 3. AI Coach Chat
- **Header**: Gradient with AI coach avatar and name "Aivy"
- **Message History**: Scrollable conversation with alternating bubbles
- **Quick Actions**: Pill-shaped suggestion chips (Ask about macros, Get workout plan)
- **Input Bar**: Sticky bottom with send button and voice input option

### 4. Meal Planner
- **Week View**: Horizontal scrollable days with meal cards
- **AI Generate Button**: Prominent CTA to create new plan
- **Meal Cards**: Image, title, calories, macros with tap to expand
- **Preferences Panel**: Dietary restrictions, calorie target with sliders and toggles

### 5. Profile
- **Header**: User photo, name, current weight, goal weight with progress bar
- **Stats Grid**: Total scans, streak days, meals logged (metric cards)
- **Goals Section**: Weight target, activity level, dietary preferences
- **Settings**: Notifications, sync status, theme toggle
- **Premium Badge**: Gradient card for upgrade features

---

## Images

**AI Coach Avatar**: Abstract geometric AI face icon with gradient (purple-cyan), used in chat header and dashboard
**Food Placeholders**: When no image scanned, use illustrated food icons with soft shadows
**Empty States**: Friendly illustrations for no data scenarios (simple line art style)
**Hero Visuals**: Not applicable - this is a utility-focused mobile app, not a landing page

---

## Accessibility & Polish

- Maintain WCAG AA contrast ratios (4.5:1 for text, 3:1 for UI elements)
- All interactive elements minimum 44x44px touch target
- Loading states: Skeleton screens with shimmer effect
- Error states: Orange accent with clear messaging and retry action
- Haptic feedback on key actions (scan, save meal, achievement unlocked)
- Dark mode fully supported with adjusted glow intensities
- Safe area padding for modern phones (notches, home indicators)