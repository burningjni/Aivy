import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, jsonb, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// User Profile with health goals and preferences
export interface UserProfile {
  id: string;
  name: string;
  age?: number;
  currentWeight?: number;
  targetWeight?: number;
  heightCm?: number;
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'active' | 'very_active';
  goal: 'lose_weight' | 'maintain' | 'gain_muscle';
  dietaryRestrictions: string[];
  dailyCalorieTarget: number;
  macroTargets: {
    protein: number; // grams
    carbs: number; // grams
    fats: number; // grams
  };
}

export const insertUserProfileSchema = z.object({
  name: z.string().min(1),
  age: z.number().optional(),
  currentWeight: z.number().optional(),
  targetWeight: z.number().optional(),
  heightCm: z.number().optional(),
  activityLevel: z.enum(['sedentary', 'light', 'moderate', 'active', 'very_active']),
  goal: z.enum(['lose_weight', 'maintain', 'gain_muscle']),
  dietaryRestrictions: z.array(z.string()),
  dailyCalorieTarget: z.number(),
  macroTargets: z.object({
    protein: z.number(),
    carbs: z.number(),
    fats: z.number(),
  }),
});

export type InsertUserProfile = z.infer<typeof insertUserProfileSchema>;

// Food Analysis from AI Vision
export interface FoodAnalysis {
  id: string;
  userId: string;
  imageUrl?: string;
  imageBase64?: string;
  foodName: string;
  calories: number;
  macros: {
    protein: number; // grams
    carbs: number; // grams
    fats: number; // grams
  };
  servingSize: string;
  confidence: number; // 0-1
  timestamp: Date;
  addedToLog: boolean;
}

export const insertFoodAnalysisSchema = z.object({
  userId: z.string(),
  imageUrl: z.string().optional(),
  imageBase64: z.string().optional(),
  foodName: z.string(),
  calories: z.number(),
  macros: z.object({
    protein: z.number(),
    carbs: z.number(),
    fats: z.number(),
  }),
  servingSize: z.string(),
  confidence: z.number(),
  addedToLog: z.boolean().optional(),
});

export type InsertFoodAnalysis = z.infer<typeof insertFoodAnalysisSchema>;

// Meal Log Entry
export interface MealLog {
  id: string;
  userId: string;
  date: string; // YYYY-MM-DD
  mealType: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  foodName: string;
  calories: number;
  macros: {
    protein: number;
    carbs: number;
    fats: number;
  };
  imageUrl?: string;
  timestamp: Date;
}

export const insertMealLogSchema = z.object({
  userId: z.string(),
  date: z.string(),
  mealType: z.enum(['breakfast', 'lunch', 'dinner', 'snack']),
  foodName: z.string(),
  calories: z.number(),
  macros: z.object({
    protein: z.number(),
    carbs: z.number(),
    fats: z.number(),
  }),
  imageUrl: z.string().optional(),
});

export type InsertMealLog = z.infer<typeof insertMealLogSchema>;

// AI Chat Messages
export interface ChatMessage {
  id: string;
  userId: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export const insertChatMessageSchema = z.object({
  userId: z.string(),
  role: z.enum(['user', 'assistant']),
  content: z.string(),
});

export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;

// Meal Plan
export interface MealPlan {
  id: string;
  userId: string;
  name: string;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  dailyMeals: {
    [date: string]: {
      breakfast: MealPlanItem;
      lunch: MealPlanItem;
      dinner: MealPlanItem;
      snacks: MealPlanItem[];
    };
  };
  generatedBy: 'ai' | 'user';
  timestamp: Date;
}

export interface MealPlanItem {
  name: string;
  description: string;
  calories: number;
  macros: {
    protein: number;
    carbs: number;
    fats: number;
  };
}

export const insertMealPlanSchema = z.object({
  userId: z.string(),
  name: z.string(),
  startDate: z.string(),
  endDate: z.string(),
  dailyMeals: z.record(z.object({
    breakfast: z.object({
      name: z.string(),
      description: z.string(),
      calories: z.number(),
      macros: z.object({
        protein: z.number(),
        carbs: z.number(),
        fats: z.number(),
      }),
    }),
    lunch: z.object({
      name: z.string(),
      description: z.string(),
      calories: z.number(),
      macros: z.object({
        protein: z.number(),
        carbs: z.number(),
        fats: z.number(),
      }),
    }),
    dinner: z.object({
      name: z.string(),
      description: z.string(),
      calories: z.number(),
      macros: z.object({
        protein: z.number(),
        carbs: z.number(),
        fats: z.number(),
      }),
    }),
    snacks: z.array(z.object({
      name: z.string(),
      description: z.string(),
      calories: z.number(),
      macros: z.object({
        protein: z.number(),
        carbs: z.number(),
        fats: z.number(),
      }),
    })),
  })),
  generatedBy: z.enum(['ai', 'user']),
});

export type InsertMealPlan = z.infer<typeof insertMealPlanSchema>;

// Workout Plan
export interface WorkoutPlan {
  id: string;
  userId: string;
  name: string;
  description: string;
  exercises: Exercise[];
  durationMinutes: number;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  focusArea: string[];
  generatedBy: 'ai' | 'user';
  timestamp: Date;
}

export interface Exercise {
  name: string;
  sets: number;
  reps: string; // e.g., "10-12" or "30 seconds"
  restSeconds: number;
  instructions: string;
}

export const insertWorkoutPlanSchema = z.object({
  userId: z.string(),
  name: z.string(),
  description: z.string(),
  exercises: z.array(z.object({
    name: z.string(),
    sets: z.number(),
    reps: z.string(),
    restSeconds: z.number(),
    instructions: z.string(),
  })),
  durationMinutes: z.number(),
  difficulty: z.enum(['beginner', 'intermediate', 'advanced']),
  focusArea: z.array(z.string()),
  generatedBy: z.enum(['ai', 'user']),
});

export type InsertWorkoutPlan = z.infer<typeof insertWorkoutPlanSchema>;

// Daily Stats Summary
export interface DailyStats {
  date: string; // YYYY-MM-DD
  totalCalories: number;
  macros: {
    protein: number;
    carbs: number;
    fats: number;
  };
  waterIntakeMl: number;
  mealsLogged: number;
}

// Water Log Entry
export interface WaterLog {
  id: string;
  userId: string;
  date: string; // YYYY-MM-DD
  amountMl: number;
  timestamp: Date;
}

export const insertWaterLogSchema = z.object({
  userId: z.string(),
  date: z.string(),
  amountMl: z.number(),
});

export type InsertWaterLog = z.infer<typeof insertWaterLogSchema>;
