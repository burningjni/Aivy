import OpenAI from "openai";

// Using OpenRouter API for access to multiple AI models
const openai = new OpenAI({
  apiKey: process.env.OPENROUTER_API_KEY,
  baseURL: "https://openrouter.ai/api/v1",
  defaultHeaders: {
    "HTTP-Referer": process.env.APP_URL || "http://localhost:5000",
    "X-Title": "Aivy - AI Fitness Companion"
  }
});

export async function analyzeFoodImage(base64Image: string): Promise<{
  foodName: string;
  calories: number;
  macros: { protein: number; carbs: number; fats: number };
  servingSize: string;
  confidence: number;
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "anthropic/claude-3.5-sonnet",
      messages: [
        {
          role: "system",
          content: `You are a nutrition expert AI. Analyze food images and provide detailed nutritional information. 
          Respond with JSON in this exact format: 
          {
            "foodName": "string",
            "calories": number,
            "macros": {
              "protein": number,
              "carbs": number,
              "fats": number
            },
            "servingSize": "string (e.g., '1 cup', '200g')",
            "confidence": number (0-1)
          }
          Be as accurate as possible based on visual cues.`,
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Analyze this food image and provide nutritional information including food name, total calories, macros (protein, carbs, fats in grams), serving size, and your confidence level."
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`
              }
            }
          ],
        },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 2048,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      foodName: result.foodName || "Unknown Food",
      calories: result.calories || 0,
      macros: {
        protein: result.macros?.protein || 0,
        carbs: result.macros?.carbs || 0,
        fats: result.macros?.fats || 0,
      },
      servingSize: result.servingSize || "1 serving",
      confidence: Math.min(1, Math.max(0, result.confidence || 0.5)),
    };
  } catch (error) {
    console.error("Error analyzing food image:", error);
    throw new Error("Failed to analyze food image");
  }
}

export async function chatWithAI(messages: Array<{ role: "user" | "assistant"; content: string }>): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "anthropic/claude-3.5-sonnet",
      messages: [
        {
          role: "system",
          content: `You are Aivy, a friendly and knowledgeable AI health coach specializing in nutrition and fitness. 
          You provide personalized advice, answer health questions, and help users achieve their wellness goals.
          Be supportive, encouraging, and provide actionable advice. Keep responses concise but informative.
          Focus on evidence-based recommendations and never provide medical advice for serious conditions.`,
        },
        ...messages,
      ],
      max_completion_tokens: 8192,
    });

    return response.choices[0].message.content || "I'm sorry, I couldn't process that. Could you please rephrase?";
  } catch (error) {
    console.error("Error in AI chat:", error);
    throw new Error("Failed to get AI response");
  }
}

export async function generateMealPlan(userGoal: string, calories: number, dietaryRestrictions: string[]): Promise<any> {
  try {
    const response = await openai.chat.completions.create({
      model: "anthropic/claude-3.5-sonnet",
      messages: [
        {
          role: "system",
          content: `You are a professional nutritionist creating personalized meal plans. 
          Generate a 7-day meal plan with breakfast, lunch, dinner, and snacks.
          Respond with JSON in this format:
          {
            "dailyMeals": {
              "monday": {
                "breakfast": { "name": "string", "description": "string", "calories": number, "macros": {"protein": number, "carbs": number, "fats": number} },
                "lunch": { "name": "string", "description": "string", "calories": number, "macros": {"protein": number, "carbs": number, "fats": number} },
                "dinner": { "name": "string", "description": "string", "calories": number, "macros": {"protein": number, "carbs": number, "fats": number} },
                "snacks": [{ "name": "string", "description": "string", "calories": number, "macros": {"protein": number, "carbs": number, "fats": number} }]
              },
              // ... repeat for tuesday through sunday
            }
          }`,
        },
        {
          role: "user",
          content: `Create a 7-day meal plan for someone with these goals:
          - Goal: ${userGoal}
          - Daily calorie target: ${calories}
          - Dietary restrictions: ${dietaryRestrictions.join(", ") || "None"}
          
          Make it varied, delicious, and nutritionally balanced.`,
        },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 8192,
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    console.error("Error generating meal plan:", error);
    throw new Error("Failed to generate meal plan");
  }
}

export async function generateWorkoutPlan(goal: string, fitnessLevel: string, focusAreas: string[]): Promise<any> {
  try {
    const response = await openai.chat.completions.create({
      model: "anthropic/claude-3.5-sonnet",
      messages: [
        {
          role: "system",
          content: `You are a certified fitness trainer creating personalized workout plans.
          Respond with JSON in this format:
          {
            "name": "string",
            "description": "string",
            "exercises": [
              {
                "name": "string",
                "sets": number,
                "reps": "string (e.g., '10-12' or '30 seconds')",
                "restSeconds": number,
                "instructions": "string"
              }
            ],
            "durationMinutes": number
          }`,
        },
        {
          role: "user",
          content: `Create a workout plan for:
          - Goal: ${goal}
          - Fitness level: ${fitnessLevel}
          - Focus areas: ${focusAreas.join(", ")}
          
          Make it effective, safe, and appropriate for the fitness level.`,
        },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 8192,
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    console.error("Error generating workout plan:", error);
    throw new Error("Failed to generate workout plan");
  }
}
