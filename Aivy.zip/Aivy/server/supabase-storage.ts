import { supabase } from './supabase';

export const supabaseStorage = {
  async getUserProfile(userId: string) {
    const { data, error } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('user_id', userId)
      .single();
    
    if (error && error.code !== 'PGRST116') throw error;
    return data;
  },

  async updateUserProfile(userId: string, updates: any) {
    const { data, error } = await supabase
      .from('user_profiles')
      .update(updates)
      .eq('user_id', userId)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async createMealLog(mealData: any) {
    const { data, error } = await supabase
      .from('meal_logs')
      .insert(mealData)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async getMealLogs(userId: string, date?: string) {
    let query = supabase
      .from('meal_logs')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    
    if (date) {
      query = query.eq('date', date);
    }
    
    const { data, error } = await query;
    if (error) throw error;
    return data || [];
  },

  async getDailyStats(userId: string, date: string) {
    const { data: meals, error } = await supabase
      .from('meal_logs')
      .select('calories, protein_g, carbs_g, fat_g')
      .eq('user_id', userId)
      .eq('date', date);
    
    if (error) throw error;

    const stats = (meals || []).reduce(
      (acc, meal) => ({
        calories: acc.calories + (meal.calories || 0),
        protein: acc.protein + (meal.protein_g || 0),
        carbs: acc.carbs + (meal.carbs_g || 0),
        fats: acc.fats + (meal.fat_g || 0),
      }),
      { calories: 0, protein: 0, carbs: 0, fats: 0 }
    );

    const { data: waterLogs } = await supabase
      .from('water_logs')
      .select('amount_ml')
      .eq('user_id', userId)
      .eq('date', date);

    const waterIntake = (waterLogs || []).reduce((sum, log) => sum + log.amount_ml, 0);

    return {
      date,
      ...stats,
      waterIntakeMl: waterIntake,
    };
  },

  async getWeeklyStats(userId: string) {
    const today = new Date();
    const sevenDaysAgo = new Date(today);
    sevenDaysAgo.setDate(today.getDate() - 7);

    const { data: meals, error } = await supabase
      .from('meal_logs')
      .select('date, calories')
      .eq('user_id', userId)
      .gte('date', sevenDaysAgo.toISOString().split('T')[0])
      .lte('date', today.toISOString().split('T')[0]);

    if (error) throw error;

    const dailyCalories: Record<string, number> = {};
    (meals || []).forEach((meal) => {
      dailyCalories[meal.date] = (dailyCalories[meal.date] || 0) + meal.calories;
    });

    const weeklyData = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(today.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      weeklyData.push({
        date: dateStr,
        calories: dailyCalories[dateStr] || 0,
      });
    }

    return weeklyData;
  },

  async getUserStreak(userId: string) {
    const { data: meals, error } = await supabase
      .from('meal_logs')
      .select('date')
      .eq('user_id', userId)
      .order('date', { ascending: false });

    if (error) throw error;

    if (!meals || meals.length === 0) return 0;

    const uniqueDates = Array.from(new Set(meals.map(m => m.date))).sort().reverse();
    let streak = 0;
    const today = new Date().toISOString().split('T')[0];
    
    for (let i = 0; i < uniqueDates.length; i++) {
      const expectedDate = new Date();
      expectedDate.setDate(expectedDate.getDate() - i);
      const expectedDateStr = expectedDate.toISOString().split('T')[0];
      
      if (uniqueDates[i] === expectedDateStr) {
        streak++;
      } else {
        break;
      }
    }

    return streak;
  },

  async addWaterLog(waterData: any) {
    const { data: existing } = await supabase
      .from('water_logs')
      .select('id, amount_ml')
      .eq('user_id', waterData.user_id)
      .eq('date', waterData.date)
      .single();

    if (existing) {
      const { data, error } = await supabase
        .from('water_logs')
        .update({ amount_ml: existing.amount_ml + waterData.amount_ml })
        .eq('id', existing.id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } else {
      const { data, error } = await supabase
        .from('water_logs')
        .insert(waterData)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    }
  },

  async createChatMessage(messageData: any) {
    const { data, error } = await supabase
      .from('chat_messages')
      .insert(messageData)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async getChatHistory(userId: string, limit = 50) {
    const { data, error } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: true })
      .limit(limit);
    
    if (error) throw error;
    return data || [];
  },

  async createMealPlan(planData: any) {
    const { data, error } = await supabase
      .from('meal_plans')
      .insert(planData)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async getMealPlans(userId: string) {
    const { data, error } = await supabase
      .from('meal_plans')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return data || [];
  },

  async createWorkoutPlan(workoutData: any) {
    const { data, error } = await supabase
      .from('workout_plans')
      .insert(workoutData)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async getWorkoutPlans(userId: string) {
    const { data, error } = await supabase
      .from('workout_plans')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return data || [];
  },
};
