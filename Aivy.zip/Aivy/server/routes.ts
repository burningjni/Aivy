import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { analyzeFoodImage, chatWithAI, generateMealPlan, generateWorkoutPlan } from "./openai";
import { 
  insertFoodAnalysisSchema,
  insertMealLogSchema,
  insertChatMessageSchema,
  insertUserProfileSchema,
} from "@shared/schema";
import multer from "multer";

const upload = multer({ storage: multer.memoryStorage() });

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok" });
  });

  // User Profile routes
  app.get("/api/profile", async (req, res) => {
    try {
      const userId = "demo-user-1"; // In a real app, get from session/auth
      const profile = await storage.getUserProfile(userId);
      
      if (!profile) {
        return res.status(404).json({ error: "Profile not found" });
      }
      
      res.json(profile);
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ error: "Failed to fetch profile" });
    }
  });

  app.put("/api/profile", async (req, res) => {
    try {
      const userId = "demo-user-1";
      const validated = insertUserProfileSchema.partial().parse(req.body);
      
      const updated = await storage.updateUserProfile(userId, validated);
      
      if (!updated) {
        return res.status(404).json({ error: "Profile not found" });
      }
      
      res.json(updated);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(400).json({ error: "Invalid profile data" });
    }
  });

  // Food Analysis with AI Vision
  app.post("/api/analyze-food", upload.single("image"), async (req, res) => {
    try {
      const userId = "demo-user-1";
      
      if (!req.file) {
        return res.status(400).json({ error: "No image provided" });
      }

      // Convert image buffer to base64
      const base64Image = req.file.buffer.toString("base64");
      
      // Analyze with GPT-5 Vision
      const analysis = await analyzeFoodImage(base64Image);
      
      // Save to storage
      const saved = await storage.createFoodAnalysis({
        userId,
        imageBase64: base64Image,
        ...analysis,
      });
      
      res.json(saved);
    } catch (error) {
      console.error("Error analyzing food:", error);
      const message = error instanceof Error ? error.message : "Failed to analyze food image";
      res.status(500).json({ error: `Food analysis failed: ${message}. Please try again.` });
    }
  });

  // Meal Log routes
  app.post("/api/meal-log", async (req, res) => {
    try {
      const userId = "demo-user-1";
      const validated = insertMealLogSchema.parse({
        ...req.body,
        userId,
      });
      
      const log = await storage.createMealLog(validated);
      res.json(log);
    } catch (error) {
      console.error("Error creating meal log:", error);
      res.status(400).json({ error: "Invalid meal log data" });
    }
  });

  app.get("/api/meal-log", async (req, res) => {
    try {
      const userId = "demo-user-1";
      const date = req.query.date as string | undefined;
      
      const logs = await storage.getMealLogs(userId, date);
      res.json(logs);
    } catch (error) {
      console.error("Error fetching meal logs:", error);
      res.status(500).json({ error: "Failed to fetch meal logs" });
    }
  });

  // Daily Stats
  app.get("/api/daily-stats", async (req, res) => {
    try {
      const userId = "demo-user-1";
      const date = req.query.date as string || new Date().toISOString().split('T')[0];
      
      const stats = await storage.getDailyStats(userId, date);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching daily stats:", error);
      res.status(500).json({ error: "Failed to fetch daily stats" });
    }
  });

  // Weekly Stats
  app.get("/api/weekly-stats", async (req, res) => {
    try {
      const userId = "demo-user-1";
      const stats = await storage.getWeeklyStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching weekly stats:", error);
      res.status(500).json({ error: "Failed to fetch weekly stats" });
    }
  });

  // User Streak
  app.get("/api/streak", async (req, res) => {
    try {
      const userId = "demo-user-1";
      const streak = await storage.getUserStreak(userId);
      res.json({ streak });
    } catch (error) {
      console.error("Error fetching streak:", error);
      res.status(500).json({ error: "Failed to fetch streak" });
    }
  });

  // Water Log routes
  app.post("/api/water-log", async (req, res) => {
    try {
      const userId = "demo-user-1";
      const { amountMl } = req.body;
      
      if (!amountMl || typeof amountMl !== 'number' || amountMl <= 0) {
        return res.status(400).json({ error: "Valid water amount is required" });
      }
      
      const log = await storage.addWaterLog({
        userId,
        date: new Date().toISOString().split('T')[0],
        amountMl,
      });
      
      res.json(log);
    } catch (error) {
      console.error("Error logging water:", error);
      const message = error instanceof Error ? error.message : "Failed to log water";
      res.status(400).json({ error: message });
    }
  });

  // AI Chat routes
  app.post("/api/chat", async (req, res) => {
    try {
      const userId = "demo-user-1";
      const { message } = req.body;
      
      if (!message || typeof message !== "string") {
        return res.status(400).json({ error: "Message is required" });
      }
      
      // Save user message
      await storage.createChatMessage({
        userId,
        role: "user",
        content: message,
      });
      
      // Get chat history for context
      const history = await storage.getChatHistory(userId, 10);
      const messages = history.map((msg) => ({
        role: msg.role,
        content: msg.content,
      }));
      
      // Get AI response
      const aiResponse = await chatWithAI(messages);
      
      // Save AI message
      const savedMessage = await storage.createChatMessage({
        userId,
        role: "assistant",
        content: aiResponse,
      });
      
      res.json(savedMessage);
    } catch (error) {
      console.error("Error in chat:", error);
      const message = error instanceof Error ? error.message : "Failed to get AI response";
      res.status(500).json({ error: `Chat failed: ${message}. Please try again.` });
    }
  });

  app.get("/api/chat-history", async (req, res) => {
    try {
      const userId = "demo-user-1";
      const history = await storage.getChatHistory(userId);
      res.json(history);
    } catch (error) {
      console.error("Error fetching chat history:", error);
      res.status(500).json({ error: "Failed to fetch chat history" });
    }
  });

  // AI Meal Plan Generation
  app.post("/api/generate-meal-plan", async (req, res) => {
    try {
      const userId = "demo-user-1";
      const profile = await storage.getUserProfile(userId);
      
      if (!profile) {
        return res.status(404).json({ error: "Profile not found" });
      }
      
      const { startDate, endDate, name } = req.body;
      
      // Generate meal plan with AI
      const aiPlan = await generateMealPlan(
        profile.goal,
        profile.dailyCalorieTarget,
        profile.dietaryRestrictions
      );
      
      const mealPlan = await storage.createMealPlan({
        userId,
        name: name || `AI Meal Plan - ${new Date().toLocaleDateString()}`,
        startDate: startDate || new Date().toISOString().split('T')[0],
        endDate: endDate || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        dailyMeals: aiPlan.dailyMeals,
        generatedBy: "ai",
      });
      
      res.json(mealPlan);
    } catch (error) {
      console.error("Error generating meal plan:", error);
      res.status(500).json({ error: "Failed to generate meal plan" });
    }
  });

  app.get("/api/meal-plans", async (req, res) => {
    try {
      const userId = "demo-user-1";
      const plans = await storage.getMealPlans(userId);
      res.json(plans);
    } catch (error) {
      console.error("Error fetching meal plans:", error);
      res.status(500).json({ error: "Failed to fetch meal plans" });
    }
  });

  // AI Workout Plan Generation
  app.post("/api/generate-workout", async (req, res) => {
    try {
      const userId = "demo-user-1";
      const profile = await storage.getUserProfile(userId);
      
      if (!profile) {
        return res.status(404).json({ error: "Profile not found" });
      }
      
      const { fitnessLevel, focusAreas } = req.body;
      
      // Generate workout plan with AI
      const aiWorkout = await generateWorkoutPlan(
        profile.goal,
        fitnessLevel || profile.activityLevel,
        focusAreas || ["full body"]
      );
      
      const workoutPlan = await storage.createWorkoutPlan({
        userId,
        name: aiWorkout.name,
        description: aiWorkout.description,
        exercises: aiWorkout.exercises,
        durationMinutes: aiWorkout.durationMinutes,
        difficulty: fitnessLevel || "intermediate",
        focusArea: focusAreas || ["full body"],
        generatedBy: "ai",
      });
      
      res.json(workoutPlan);
    } catch (error) {
      console.error("Error generating workout:", error);
      res.status(500).json({ error: "Failed to generate workout plan" });
    }
  });

  app.get("/api/workout-plans", async (req, res) => {
    try {
      const userId = "demo-user-1";
      const plans = await storage.getWorkoutPlans(userId);
      res.json(plans);
    } catch (error) {
      console.error("Error fetching workout plans:", error);
      res.status(500).json({ error: "Failed to fetch workout plans" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
