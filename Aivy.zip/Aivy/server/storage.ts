import { 
  type User, 
  type InsertUser,
  type UserProfile,
  type InsertUserProfile,
  type FoodAnalysis,
  type InsertFoodAnalysis,
  type MealLog,
  type InsertMealLog,
  type ChatMessage,
  type InsertChatMessage,
  type MealPlan,
  type InsertMealPlan,
  type WorkoutPlan,
  type InsertWorkoutPlan,
  type DailyStats,
  type WaterLog,
  type InsertWaterLog,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // User Profile methods
  getUserProfile(userId: string): Promise<UserProfile | undefined>;
  createUserProfile(profile: InsertUserProfile & { id: string }): Promise<UserProfile>;
  updateUserProfile(userId: string, profile: Partial<InsertUserProfile>): Promise<UserProfile | undefined>;
  
  // Food Analysis methods
  createFoodAnalysis(analysis: InsertFoodAnalysis): Promise<FoodAnalysis>;
  getFoodAnalyses(userId: string, limit?: number): Promise<FoodAnalysis[]>;
  
  // Meal Log methods
  createMealLog(log: InsertMealLog): Promise<MealLog>;
  getMealLogs(userId: string, date?: string): Promise<MealLog[]>;
  getMealLogsByDateRange(userId: string, startDate: string, endDate: string): Promise<MealLog[]>;
  
  // Chat methods
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  getChatHistory(userId: string, limit?: number): Promise<ChatMessage[]>;
  
  // Meal Plan methods
  createMealPlan(plan: InsertMealPlan): Promise<MealPlan>;
  getMealPlans(userId: string): Promise<MealPlan[]>;
  getMealPlan(id: string): Promise<MealPlan | undefined>;
  
  // Workout Plan methods
  createWorkoutPlan(plan: InsertWorkoutPlan): Promise<WorkoutPlan>;
  getWorkoutPlans(userId: string): Promise<WorkoutPlan[]>;
  
  // Water tracking methods
  addWaterLog(log: InsertWaterLog): Promise<WaterLog>;
  getWaterLogs(userId: string, date: string): Promise<WaterLog[]>;
  
  // Stats methods
  getDailyStats(userId: string, date: string): Promise<DailyStats>;
  getWeeklyStats(userId: string): Promise<Array<{ date: string; calories: number }>>;
  getUserStreak(userId: string): Promise<number>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private profiles: Map<string, UserProfile>;
  private foodAnalyses: Map<string, FoodAnalysis>;
  private mealLogs: Map<string, MealLog>;
  private chatMessages: Map<string, ChatMessage>;
  private mealPlans: Map<string, MealPlan>;
  private workoutPlans: Map<string, WorkoutPlan>;
  private waterLogs: Map<string, WaterLog>;

  constructor() {
    this.users = new Map();
    this.profiles = new Map();
    this.foodAnalyses = new Map();
    this.mealLogs = new Map();
    this.chatMessages = new Map();
    this.mealPlans = new Map();
    this.workoutPlans = new Map();
    this.waterLogs = new Map();
    
    // Create default user and profile for demo
    const defaultUserId = "demo-user-1";
    this.users.set(defaultUserId, {
      id: defaultUserId,
      username: "demo",
      password: "demo",
    });
    
    this.profiles.set(defaultUserId, {
      id: defaultUserId,
      name: "Alex Johnson",
      age: 28,
      currentWeight: 78,
      targetWeight: 75,
      heightCm: 175,
      activityLevel: "moderate",
      goal: "lose_weight",
      dietaryRestrictions: ["vegetarian", "no dairy"],
      dailyCalorieTarget: 2000,
      macroTargets: {
        protein: 112,
        carbs: 200,
        fats: 67,
      },
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getUserProfile(userId: string): Promise<UserProfile | undefined> {
    return this.profiles.get(userId);
  }

  async createUserProfile(profile: InsertUserProfile & { id: string }): Promise<UserProfile> {
    const userProfile: UserProfile = {
      ...profile,
    };
    this.profiles.set(profile.id, userProfile);
    return userProfile;
  }

  async updateUserProfile(userId: string, profile: Partial<InsertUserProfile>): Promise<UserProfile | undefined> {
    const existing = this.profiles.get(userId);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...profile };
    this.profiles.set(userId, updated);
    return updated;
  }

  async createFoodAnalysis(analysis: InsertFoodAnalysis): Promise<FoodAnalysis> {
    const id = randomUUID();
    const foodAnalysis: FoodAnalysis = {
      ...analysis,
      id,
      timestamp: new Date(),
      addedToLog: analysis.addedToLog || false,
    };
    this.foodAnalyses.set(id, foodAnalysis);
    return foodAnalysis;
  }

  async getFoodAnalyses(userId: string, limit = 50): Promise<FoodAnalysis[]> {
    return Array.from(this.foodAnalyses.values())
      .filter((a) => a.userId === userId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  async createMealLog(log: InsertMealLog): Promise<MealLog> {
    const id = randomUUID();
    const mealLog: MealLog = {
      ...log,
      id,
      timestamp: new Date(),
    };
    this.mealLogs.set(id, mealLog);
    return mealLog;
  }

  async getMealLogs(userId: string, date?: string): Promise<MealLog[]> {
    return Array.from(this.mealLogs.values())
      .filter((log) => {
        if (log.userId !== userId) return false;
        if (date && log.date !== date) return false;
        return true;
      })
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async getMealLogsByDateRange(userId: string, startDate: string, endDate: string): Promise<MealLog[]> {
    return Array.from(this.mealLogs.values())
      .filter((log) => {
        return log.userId === userId && log.date >= startDate && log.date <= endDate;
      })
      .sort((a, b) => a.date.localeCompare(b.date));
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const id = randomUUID();
    const chatMessage: ChatMessage = {
      ...message,
      id,
      timestamp: new Date(),
    };
    this.chatMessages.set(id, chatMessage);
    return chatMessage;
  }

  async getChatHistory(userId: string, limit = 100): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values())
      .filter((msg) => msg.userId === userId)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime())
      .slice(-limit);
  }

  async createMealPlan(plan: InsertMealPlan): Promise<MealPlan> {
    const id = randomUUID();
    const mealPlan: MealPlan = {
      ...plan,
      id,
      timestamp: new Date(),
    };
    this.mealPlans.set(id, mealPlan);
    return mealPlan;
  }

  async getMealPlans(userId: string): Promise<MealPlan[]> {
    return Array.from(this.mealPlans.values())
      .filter((plan) => plan.userId === userId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async getMealPlan(id: string): Promise<MealPlan | undefined> {
    return this.mealPlans.get(id);
  }

  async createWorkoutPlan(plan: InsertWorkoutPlan): Promise<WorkoutPlan> {
    const id = randomUUID();
    const workoutPlan: WorkoutPlan = {
      ...plan,
      id,
      timestamp: new Date(),
    };
    this.workoutPlans.set(id, workoutPlan);
    return workoutPlan;
  }

  async getWorkoutPlans(userId: string): Promise<WorkoutPlan[]> {
    return Array.from(this.workoutPlans.values())
      .filter((plan) => plan.userId === userId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async addWaterLog(log: InsertWaterLog): Promise<WaterLog> {
    const id = randomUUID();
    const waterLog: WaterLog = {
      ...log,
      id,
      timestamp: new Date(),
    };
    this.waterLogs.set(id, waterLog);
    return waterLog;
  }

  async getWaterLogs(userId: string, date: string): Promise<WaterLog[]> {
    return Array.from(this.waterLogs.values())
      .filter((log) => log.userId === userId && log.date === date)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }

  async getDailyStats(userId: string, date: string): Promise<DailyStats> {
    const logs = await this.getMealLogs(userId, date);
    const waterLogs = await this.getWaterLogs(userId, date);
    
    const totalCalories = logs.reduce((sum, log) => sum + log.calories, 0);
    const macros = logs.reduce(
      (acc, log) => ({
        protein: acc.protein + log.macros.protein,
        carbs: acc.carbs + log.macros.carbs,
        fats: acc.fats + log.macros.fats,
      }),
      { protein: 0, carbs: 0, fats: 0 }
    );
    
    const waterIntakeMl = waterLogs.reduce((sum, log) => sum + log.amountMl, 0);

    return {
      date,
      totalCalories,
      macros,
      waterIntakeMl,
      mealsLogged: logs.length,
    };
  }

  async getWeeklyStats(userId: string): Promise<Array<{ date: string; calories: number }>> {
    const today = new Date();
    const weekAgo = new Date(today);
    weekAgo.setDate(today.getDate() - 6); // Last 7 days including today
    
    const startDate = weekAgo.toISOString().split('T')[0];
    const endDate = today.toISOString().split('T')[0];
    
    // Get all logs for the week
    const logs = await this.getMealLogsByDateRange(userId, startDate, endDate);
    
    // Group by date and sum calories
    const dailyCalories = new Map<string, number>();
    
    // Initialize all 7 days with 0 calories
    for (let i = 0; i < 7; i++) {
      const date = new Date(weekAgo);
      date.setDate(weekAgo.getDate() + i);
      const dateStr = date.toISOString().split('T')[0];
      dailyCalories.set(dateStr, 0);
    }
    
    // Aggregate calories from logs
    logs.forEach(log => {
      const current = dailyCalories.get(log.date) || 0;
      dailyCalories.set(log.date, current + log.calories);
    });
    
    // Convert to array and sort by date
    return Array.from(dailyCalories.entries())
      .map(([date, calories]) => ({ date, calories }))
      .sort((a, b) => a.date.localeCompare(b.date));
  }

  async getUserStreak(userId: string): Promise<number> {
    const today = new Date();
    let streak = 0;
    let currentDate = new Date(today);
    
    // Check backwards from today until we find a day with no meals
    while (true) {
      const dateStr = currentDate.toISOString().split('T')[0];
      const logs = await this.getMealLogs(userId, dateStr);
      
      if (logs.length === 0) {
        break;
      }
      
      streak++;
      currentDate.setDate(currentDate.getDate() - 1);
      
      // Safety limit to prevent infinite loop
      if (streak > 365) break;
    }
    
    return streak;
  }
}

export const storage = new MemStorage();
