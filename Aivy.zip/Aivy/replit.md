# Aivy - AI Nutrition & Fitness Companion

## Overview
Aivy is a stunning, mobile-first AI-powered nutrition and fitness companion built with React, Express, and AI (via OpenRouter). The app combines cutting-edge AI technology with a beautiful, futuristic design to help users achieve their health goals through personalized coaching, food analysis, and nutrition tracking.

## Current State
**Status**: Production Ready ✅ (October 2025)

### Implemented Features
- ✅ **User Authentication** - Email OTP verification + Google Sign-In via Supabase Auth
- ✅ **User Onboarding** - 3-step registration collecting name, age, height, weight, goals, activity level, and dietary restrictions
- ✅ **AI Food Scanner** - Upload food photos for instant AI-powered nutritional analysis
- ✅ **AI Coach Chat** - Conversational health advice and personalized recommendations
- ✅ **Smart Nutrition Tracker** - Daily calorie and macro tracking with visual progress charts
- ✅ **Meal Planner** - AI-generated personalized 7-day meal plans based on user goals
- ✅ **User Profile** - Goal setting, dietary preferences, and progress tracking
- ✅ **Beautiful UI** - Mobile-optimized design with gradient effects, glassmorphic cards, and smooth animations
- ✅ **Dark Mode Default** - Dark theme by default with toggle option
- ✅ **Real-time Stats** - Dashboard showing daily calories, macros, water intake, and streaks
- ✅ **Persistent Storage** - All data stored in Supabase PostgreSQL with Row Level Security

## Recent Changes (October 2025)
- **Switched to Dark Theme by Default** - App now opens in dark mode instead of light mode
- **Integrated Supabase Authentication**:
  - Email OTP verification (6-digit code sent to email)
  - Google OAuth Sign-In
  - Protected routes with authentication guards
- **Created User Onboarding Flow**:
  - Step 1: Name, Age, Height, Current Weight
  - Step 2: Goal Weight, Primary Goal, Dietary Restrictions
  - Step 3: Activity Level
  - Automatic macro calculation based on user inputs
- **Replaced OpenAI with OpenRouter API** - Access to 400+ AI models via single API
- **Migrated to Supabase Storage** - Replaced in-memory storage with PostgreSQL database
- **Added Authentication Pages**:
  - Sign In page with email/password and Google OAuth
  - Sign Up page with email OTP flow
  - Email Verification page with 6-digit code input
  - Onboarding page with 3-step form

## Project Architecture

### Tech Stack
- **Frontend**: React 18, TypeScript, Tailwind CSS, Shadcn UI, Wouter (routing)
- **Backend**: Express, Node.js, TypeScript
- **Database**: Supabase PostgreSQL with Row Level Security
- **Authentication**: Supabase Auth (Email OTP + Google OAuth)
- **Data Visualization**: Recharts for charts and graphs
- **State Management**: TanStack Query (React Query)
- **AI**: OpenRouter API (Claude 3.5 Sonnet for all AI features)

### Authentication Flow
1. User visits `/signup`
2. Enters email → receives 6-digit OTP code
3. Verifies email on `/verify-email` page
4. Completes onboarding on `/onboarding` page (3 steps)
5. Profile created in Supabase with calculated macros
6. Redirected to dashboard

### Key Components
- **BottomNav**: Fixed bottom navigation with 5 tabs (Home, Scan, Coach, Meals, Profile)
- **StatCard**: Reusable glassmorphic stat cards with gradient icons
- **MacroChart**: Donut chart for macro breakdown visualization
- **ThemeToggle**: Dark/light mode switcher (defaults to dark)
- **LoadingState**: Beautiful loading indicators with pulse animations
- **ProtectedRoute**: Authentication guard component for private routes
- **PublicRoute**: Redirect authenticated users away from auth pages

### API Endpoints
- `POST /api/analyze-food` - Analyze food image with AI Vision (requires auth)
- `POST /api/chat` - Send message to AI coach (requires auth)
- `GET /api/chat-history` - Get conversation history (requires auth)
- `POST /api/meal-log` - Add meal to daily log (requires auth)
- `GET /api/meal-log` - Get meal logs (requires auth, optional date filter)
- `GET /api/daily-stats` - Get nutrition stats for a specific date (requires auth)
- `POST /api/generate-meal-plan` - Generate AI-powered 7-day meal plan (requires auth)
- `POST /api/generate-workout` - Generate personalized workout plan (requires auth)
- `GET /api/profile` - Get user profile (requires auth)
- `PUT /api/profile` - Update user profile (requires auth)

### Data Models (Supabase Tables)
- **user_profiles**: User info, goals, activity level, macro targets (linked to auth.users)
- **meal_logs**: Daily meal entries with calories and macros
- **chat_messages**: Conversation history with AI coach
- **meal_plans**: AI-generated weekly meal plans
- **workout_plans**: Personalized workout routines
- **water_logs**: Daily water intake tracking

### Database Security
- Row Level Security (RLS) enabled on all tables
- Users can only access their own data
- Policies enforce user_id = auth.uid() checks
- Service role key used for server-side operations only

## User Preferences
- **Default Theme**: Dark mode (user can toggle to light)
- **Design Style**: Clean, futuristic, health-focused with soft gradients
- **Color Scheme**: Blue-green primary colors with neon cyan/purple accents
- **Typography**: Inter for body text, Outfit for headings
- **Target Audience**: Health-conscious users seeking AI-powered guidance
- **Platform**: Mobile-first responsive web application
- **Authentication**: Email OTP + Google Sign-In preferred

## Design Guidelines
See `design_guidelines.md` for complete visual design specifications including:
- Color palette (light & dark modes)
- Typography scale
- Component styling (cards, buttons, inputs)
- Animation guidelines
- Accessibility standards

## Environment Variables

### Required for OpenRouter AI
- `OPENROUTER_API_KEY` - API key from https://openrouter.ai

### Required for Supabase (Backend)
- `SUPABASE_URL` - Your Supabase project URL
- `SUPABASE_SERVICE_ROLE_KEY` - Service role key (server-side only)

### Required for Supabase (Frontend)
- `VITE_SUPABASE_URL` - Your Supabase project URL (same as SUPABASE_URL)
- `VITE_SUPABASE_ANON_KEY` - Anon/public key for client-side auth

### Optional
- `APP_URL` - Your app URL for OpenRouter attribution (default: http://localhost:5000)

## Development Commands
- `npm run dev` - Start development server (frontend + backend on port 5000)
- `npm run build` - Build for production
- `npm start` - Run production build
- `npm run check` - TypeScript type checking
- `npm run db:push` - Push Drizzle schema to database (if using Drizzle)

## Setup Instructions

### 1. Run Supabase SQL Schema
Copy the contents of `supabase_schema.sql` and run it in your Supabase SQL Editor to create all tables, indexes, RLS policies, and triggers.

### 2. Enable Authentication Providers in Supabase
Go to Supabase Dashboard → Authentication → Providers:
- Enable **Email** provider (Email OTP should be on by default)
- Enable **Google** provider:
  - Create Google Cloud OAuth credentials
  - Add Client ID and Client Secret to Supabase
  - Configure authorized redirect URI

### 3. Configure Email Templates
Customize email templates in Supabase Dashboard → Authentication → Email Templates if desired.

## File Structure
```
├── client/
│   ├── src/
│   │   ├── components/      # Reusable UI components
│   │   ├── pages/           # Route pages (Home, Scan, Chat, etc.)
│   │   ├── hooks/           # Custom React hooks (useAuth, useApi)
│   │   ├── lib/             # Utilities (supabase, auth, queryClient)
│   │   ├── App.tsx          # Main app with routing & auth guards
│   │   └── main.tsx         # Entry point
│   └── index.html
├── server/
│   ├── index.ts             # Express server setup
│   ├── routes.ts            # API route handlers
│   ├── openai.ts            # OpenRouter AI integration (renamed but works with OpenRouter)
│   ├── supabase.ts          # Supabase client (server-side)
│   ├── supabase-storage.ts  # Data access layer for Supabase
│   ├── auth-middleware.ts   # JWT verification middleware
│   └── vite.ts              # Vite dev server integration
├── shared/
│   └── schema.ts            # Shared TypeScript types
├── supabase_schema.sql      # Database schema to run in Supabase
├── SETUP_INSTRUCTIONS.md    # Detailed setup guide
└── package.json
```

## Authentication & Authorization
- **Client-side**: Supabase client with anon key (RLS protects data)
- **Server-side**: Supabase client with service role key for admin operations
- **Token-based**: JWT tokens from Supabase Auth
- **Middleware**: `requireAuth` middleware verifies tokens on protected API routes
- **RLS Policies**: Database-level security ensures users only access their own data

## AI Integration (OpenRouter)
- **Model**: Claude 3.5 Sonnet (anthropic/claude-3.5-sonnet)
- **Provider**: OpenRouter API (https://openrouter.ai)
- **Use Cases**:
  - Food image analysis (Vision API)
  - Chat with AI coach
  - Meal plan generation
  - Workout plan generation
- **Cost**: Pay-as-you-go pricing through OpenRouter

## Next Phase Features (Future Enhancements)
- [ ] Push notifications for meal reminders and workout schedules
- [ ] Barcode scanning for packaged foods
- [ ] Detailed workout tracking with progress photos
- [ ] Social features (share progress, meal plans)
- [ ] Integration with fitness wearables (Apple Health, Google Fit)
- [ ] Advanced analytics and progress reports
- [ ] Recipe database with cooking instructions
- [ ] Water intake reminders with notifications
- [ ] In-app purchases for premium features
- [ ] Multi-language support

## Notes
- Using Claude 3.5 Sonnet via OpenRouter (excellent for vision and chat)
- Mobile-optimized design with touch-friendly 44px minimum tap targets
- Glassmorphic design with backdrop-blur effects
- All interactive elements have proper hover/active states
- Gradient backgrounds use CSS custom properties for easy theming
- Bottom navigation fixed with safe-area padding for modern phones
- Dark mode is default (can be toggled)
- Email OTP verification ensures verified users only
- Google Sign-In provides frictionless onboarding
- All user data secured with Supabase RLS policies
- Macro calculations automated based on user goals and activity level
