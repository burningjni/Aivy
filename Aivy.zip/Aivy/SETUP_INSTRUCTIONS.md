# Aivy Setup Instructions

## 🎉 Welcome to Aivy - Your AI Fitness Companion

This app has been configured with the following features:
- ✅ Dark theme by default
- ✅ Supabase authentication (Google + Email OTP)
- ✅ User registration with onboarding (name, age, height, weight, goals)
- ✅ OpenRouter AI integration for all AI features
- ✅ Beautiful gradient UI with glassmorphic design

## 📋 Next Steps to Complete Setup

### 1. Set Up Supabase Database

You've already added your Supabase credentials. Now run the SQL schema:

1. Go to your Supabase Dashboard: https://app.supabase.com
2. Select your project
3. Click "SQL Editor" in the left sidebar
4. Click "New Query"
5. Copy and paste the contents of `supabase_schema.sql`
6. Click "Run" to create all tables

### 2. Enable Google Sign-In in Supabase

1. In your Supabase Dashboard, go to **Authentication** → **Providers**
2. Find **Google** in the list
3. Toggle it **ON**
4. You'll need to:
   - Create a Google Cloud project at https://console.cloud.google.com
   - Enable Google+ API
   - Create OAuth 2.0 credentials
   - Add authorized redirect URIs from Supabase
   - Copy Client ID and Client Secret to Supabase

**Redirect URI format**: `https://<your-project-ref>.supabase.co/auth/v1/callback`

### 3. Configure Email Authentication

In Supabase Dashboard → **Authentication** → **Email Auth**:
- ✅ Enable Email OTP (it should be enabled by default)
- ✅ Customize email templates if desired
- ✅ Set "Confirm email" to ON for production

### 4. Test the App

1. Click "Sign Up" in the app
2. Enter your email
3. Check your email for the 6-digit OTP code
4. Enter the code to verify
5. Complete the onboarding (name, age, height, weight, goals)
6. Start using the app!

### 5. Key Features

**Authentication**:
- Email OTP verification (6-digit code)
- Google Sign-In
- Onboarding flow for new users

**AI Features** (powered by OpenRouter):
- 🍎 Food scanner (image analysis)
- 💬 AI coach chat
- 📅 Meal plan generation  
- 🏋️ Workout plan generation

**User Data** (stored in Supabase):
- User profiles with goals and targets
- Meal logs and nutrition tracking
- Chat history with AI coach
- Generated meal and workout plans

## 🔧 Configuration Files

- `.env.example` - Template for environment variables
- `supabase_schema.sql` - Database schema (run this in Supabase SQL Editor)
- `server/supabase-storage.ts` - Supabase data layer
- `client/src/lib/supabase.ts` - Supabase client configuration
- `client/src/lib/auth.ts` - Authentication functions

## 🚀 Development

The app is already running on port 5000. Visit it in the browser preview!

## 📝 Notes

- Dark theme is now the default (can be toggled)
- All user data is stored in Supabase (not in-memory)
- OpenRouter API is used for all AI features
- Google Sign-In needs to be enabled in Supabase dashboard
- Email OTP requires Supabase email templates to be configured

## 🆘 Troubleshooting

**"Failed to send verification code"**
- Check that Email OTP is enabled in Supabase
- Verify VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are set correctly

**"Google Sign-In not working"**
- Enable Google provider in Supabase Authentication settings
- Add Google OAuth credentials in Supabase

**"Session expired"**
- User needs to complete onboarding within a reasonable time after email verification
- Can restart signup process if needed

Enjoy your AI-powered fitness journey! 🎯💪
